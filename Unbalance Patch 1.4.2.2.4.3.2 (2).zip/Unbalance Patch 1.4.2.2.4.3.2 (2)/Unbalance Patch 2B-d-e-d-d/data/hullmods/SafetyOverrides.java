package data.hullmods;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.util.Misc;

public class SafetyOverrides extends BaseHullMod {

	private static Map speed = new HashMap();
	static {
		speed.put(HullSize.FRIGATE, 50f);
		speed.put(HullSize.DESTROYER, 30f);
		speed.put(HullSize.CRUISER, 20f);
		speed.put(HullSize.CAPITAL_SHIP, 10f);
	}
	
	private static Map flux = new HashMap();
	static {
		flux.put(HullSize.FRIGATE, 100f);
		flux.put(HullSize.DESTROYER, 150f);
		flux.put(HullSize.CRUISER, 200f);
		flux.put(HullSize.CAPITAL_SHIP, 300f);
	}
	private static final float PEAK_MULT = 0.33f;
	//public static final float DEGRADE_INCREASE_PERCENT = 50f;
	//private static final float OVERLOAD_DUR = 50f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getMaxSpeed().modifyFlat(id, (Float) speed.get(hullSize));
		stats.getAcceleration().modifyFlat(id, (Float) speed.get(hullSize) * 2f);
		stats.getDeceleration().modifyFlat(id, (Float) speed.get(hullSize) * 2f);
		stats.getZeroFluxMinimumFluxLevel().modifyFlat(id, 2f); // set to two, meaning boost is always on 

		stats.getFluxDissipation().modifyFlat(id, (Float) flux.get(hullSize));
		
		stats.getPeakCRDuration().modifyMult(id, PEAK_MULT);
		//stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);
		//stats.getOverloadTimeMod().modifyPercent(id, OVERLOAD_DUR);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + ((Float) speed.get(HullSize.FRIGATE)).intValue();
		if (index == 1) return "" + ((Float) speed.get(HullSize.DESTROYER)).intValue();
		if (index == 2) return "" + ((Float) speed.get(HullSize.CRUISER)).intValue();
		//if (index == 3) return "" + ((Float) speed.get(HullSize.CAPITAL_SHIP)).intValue();

		if (index == 3) return "" + ((Float) flux.get(HullSize.FRIGATE)).intValue();
		if (index == 4) return "" + ((Float) flux.get(HullSize.DESTROYER)).intValue();
		if (index == 5) return "" + ((Float) flux.get(HullSize.CRUISER)).intValue();
		//if (index == 7) return "" + ((Float) flux.get(HullSize.CAPITAL_SHIP)).intValue();

		if (index == 6) return "3";
		//if (index == 7) return "" + (int) DEGRADE_INCREASE_PERCENT + "%";
		//if (index == 8) return "" + (int) OVERLOAD_DUR + "%";
		
		return null;
	}

	@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		if (ship.getVariant().getHullSize() == HullSize.CAPITAL_SHIP) return false;
		if (ship.getVariant().hasHullMod(HullMods.DISTRIBUTED_FIRE_CONTROL)) return false;
		if (ship.getVariant().
				hasHullMod(HullMods.DEDICATED_TARGETING_CORE)) return false;
		if (ship.getVariant().hasHullMod(HullMods.INTEGRATED_TARGETING_UNIT)) return false;
		if (ship.getVariant().hasHullMod(HullMods.ADVANCED_TARGETING_CORE)) return false;
		if (ship.getVariant().hasHullMod(HullMods.FLUX_SHUNT)) return false;
		
		
		return true;
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().getHullSize() == HullSize.CAPITAL_SHIP) {
			return "Can not be installed on capital ships";
		}
		if (ship.getVariant().hasHullMod(HullMods.DISTRIBUTED_FIRE_CONTROL)) {
			return "Incompatible with Fire Control";
		}
		if (ship.getVariant().hasHullMod(HullMods.DEDICATED_TARGETING_CORE)) {
			return "Incompatible with Targeting Core";
		}
		if (ship.getVariant().hasHullMod(HullMods.INTEGRATED_TARGETING_UNIT)) {
			return "Incompatible with Targeting Unit";
		}
		if (ship.getVariant().hasHullMod(HullMods.ADVANCED_TARGETING_CORE)) {
			return "Incompatible with Targeting Core";
		}
		if (ship.getVariant().hasHullMod(HullMods.FLUX_SHUNT)) {
			return "Incompatible with Flux Shunt";
		}
		
		return null;
	}
	

	private Color color = new Color(255,100,255,255);
	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		//ship.getFluxTracker().setHardFlux(ship.getFluxTracker().getCurrFlux());
//		if (ship.getEngineController().isAccelerating() || 
//				ship.getEngineController().isAcceleratingBackwards() ||
//				ship.getEngineController().isDecelerating() ||
//				ship.getEngineController().isTurningLeft() ||
//				ship.getEngineController().isTurningRight() ||
//				ship.getEngineController().isStrafingLeft() ||
//				ship.getEngineController().isStrafingRight()) {
//			ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
//			ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
//		}
	}

	

}
