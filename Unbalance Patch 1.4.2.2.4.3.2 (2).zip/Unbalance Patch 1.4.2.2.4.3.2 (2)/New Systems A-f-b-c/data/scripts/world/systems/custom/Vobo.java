package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Vobo {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Vobo");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");

		PlanetAPI star = system.initStar("vobo",
				"star_yellow",
				800f,
				500, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(236, 191, 255)); // light color in entire system, affects all entities

		//SectorEntityToken watchman = system.addCustomEntity("abandoned_station", "Watchman", "station_side03", "tritachyon");
		//watchman.setCircularOrbitPointingDown(system.getEntityById("vobo"), 100, 1000, 40);
		//watchman.setCustomDescriptionId("station_watchman");
		//watchman.setInteractionImage("illustrations", "orbital_construction");

		JumpPointAPI jumppoint_oro = Global.getFactory().createJumpPoint("jumppoint_oro", "Oro Jump-Point");
		jumppoint_oro.setCircularOrbit(system.getEntityById("Vobo"), 100, 2100, 75);
		jumppoint_oro.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumppoint_oro);

		system.addRingBand(star, "misc", "rings_dust0", 512f, 1, new Color(225, 200, 200), 512f, 2400, 150f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 2, new Color(225, 200, 200), 512f, 2400, 100f);

		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(225, 200, 200), 512f, 3200, 200f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(225, 200, 200), 512f, 3200, 180f);

		SectorEntityToken overlord_broadcast = system.addCustomEntity("overlord_broadcast", // unique id
				"Overlord Broadcast Station", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		overlord_broadcast.setCircularOrbitPointingDown(star, -60, 3300, 100);

		system.addRingBand(star, "misc", "rings_dust0", 512f, 1, new Color(225, 200, 200), 512f, 3800, 175f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(225, 200, 200), 512f, 3800, 200f);

		PlanetAPI rippers_morld = system.addPlanet("rippers_morld", star, "Ripper's Morld", "water", -0, 140, 4450, 200);
		rippers_morld.setCustomDescriptionId("planet_rippers_morld");
		rippers_morld.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		rippers_morld.getSpec().setGlowColor(new Color(195,255,82,255));
		rippers_morld.getSpec().setUseReverseLightForGlow(true);
		rippers_morld.applySpecChanges();
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(100f, // terrain effect band width
						200, // terrain effect middle radius
						rippers_morld, // entity that it's around
						150f, // visual band start
						250f, // visual band end
						new Color(25, 77, 145, 10), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(25, 77, 145, 130),
						new Color(25, 92, 179, 150),
						new Color(36, 112, 212, 190),
						new Color(42, 130, 245, 140),
						new Color(43, 68, 255, 155),
						new Color(43, 255, 239),
						new Color(43, 201, 255)
				));
		field.setCircularOrbit(rippers_morld, 0, 0, 30);

		SectorEntityToken shade_0 = system.addCustomEntity("eventide_mirror1", "Shield Alpha-Omega 0", "stellar_shade", "tritachyon");
		shade_0.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180, 400, 200);
		shade_0.setCustomDescriptionId("stellar_shade");
		SectorEntityToken shade_1 = system.addCustomEntity("eventide_mirror2", "Shield Alpha-Omega 1", "stellar_shade", "tritachyon");
		shade_1.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180+30, 400, 200);
		shade_1.setCustomDescriptionId("stellar_shade");
		SectorEntityToken shade_2 = system.addCustomEntity("eventide_mirror3", "Shield Alpha-Omega 2", "stellar_shade", "tritachyon");
		shade_2.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180-30, 400, 200);
		shade_2.setCustomDescriptionId("stellar_shade");
		//SectorEntityToken shade_3 = system.addCustomEntity("eventide_mirror4", "Shield Alpha-Omega 3", "stellar_shade", "tritachyon");
		//shade_3.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180+180, 400, 200);
		//shade_3.setCustomDescriptionId("stellar_shade");

		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(225, 200, 200), 512f, 6400, 375f);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(225, 200, 200), 512f, 6400, 300f);
		system.addRingBand(star, "misc", "rings_asteroids0", 512f, 1, new Color(225, 200, 200), 512f, 6375, 310f);
		system.addAsteroidBelt(star, 600, 6400, 250, 600, 600, Terrain.ASTEROID_BELT, null);

		SectorEntityToken lower_control = system.addCustomEntity("lower_control", // unique id
				"Lower Control", // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		lower_control.setCircularOrbitPointingDown(star, -180, 8000, 500);

		//SectorEntityToken observer_zero = system.addCustomEntity("observer_zero", // unique id
		//		"Observer Zero", // name - if null, defaultName from custom_entities.json will be used
		//		"sensor_array_makeshift", // type of object, defined in custom_entities.json
		//		"tritachyon"); // faction
		//observer_zero.setCircularOrbitPointingDown(star, 420, 8000, 500);

		PlanetAPI living_nightmare = system.addPlanet("living_nightmare", star, "Living Nightmare", "ice_giant", 120, 410, 8000, 500);
		living_nightmare.getSpec().setCloudColor(new Color(255,245,200,220));
		living_nightmare.getSpec().setPlanetColor(new Color(0,0,0,255));
		living_nightmare.getSpec().setTilt(15);
		living_nightmare.getSpec().setAtmosphereThickness(0.5f);
		living_nightmare.getSpec().setCloudRotation(10f);
		living_nightmare.getSpec().setAtmosphereThicknessMin(80);
		living_nightmare.getSpec().setAtmosphereThickness(0.30f);
		living_nightmare.getSpec().setAtmosphereColor(new Color(255,150,50,205));
		living_nightmare.applySpecChanges();

		system.addRingBand(living_nightmare, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 800, 30f, Terrain.RING, "Passage of Neo");

		PlanetAPI broken_bone = system.addPlanet("broken_bone", living_nightmare, "Broken Bone", "barren2", 10, 100, 1100, 60);
		broken_bone.setCustomDescriptionId("planet_broken_bone");
		broken_bone.setCustomDescriptionId("planet_rippers_morld");
		broken_bone.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		broken_bone.getSpec().setGlowColor(new Color(209,255,216,255));
		broken_bone.getSpec().setUseReverseLightForGlow(true);
		broken_bone.applySpecChanges();

		SectorEntityToken broken_bone_station = system.addCustomEntity("abandoned_station", "Operation Zero", "station_mining00", "neutral");
		broken_bone_station.setCircularOrbitPointingDown(system.getEntityById("broken_bone"), -10, 200, 10);
		//broken_bone_station.setCustomDescriptionId("station_broken_bone");
		broken_bone_station.setInteractionImage("illustrations", "orbital_construction");

		PlanetAPI old_bob = system.addPlanet("old_bob", star, "Old Bob", "frozen1", -440, 150, 10000, 640);
		//old_bob.setCustomDescriptionId("planet_old_bob");
		//Misc.initConditionMarket(old_bob);;
		//old_bob.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		//old_bob.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);
		//old_bob.getMarket().addCondition(Conditions.RARE_ORE_ABUNDANT);
		//old_bob.getMarket().addCondition(Conditions.ORE_ABUNDANT);
		//old_bob.getMarket().addCondition(Conditions.NO_ATMOSPHERE);

		JumpPointAPI jumppoint2 = Global.getFactory().createJumpPoint("jumppoint_oro", "Oro Jump-Point");
		jumppoint2.setCircularOrbit(system.getEntityById("Vobo"), -440 + 60, 10000, 640);
		jumppoint2.setRelatedPlanet(old_bob);
		//jumppoint_oro.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumppoint2);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				3, 5, // min/max entities to add
				11000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
