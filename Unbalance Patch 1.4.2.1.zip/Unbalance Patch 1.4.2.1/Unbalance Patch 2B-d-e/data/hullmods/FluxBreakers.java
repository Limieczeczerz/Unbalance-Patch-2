package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class FluxBreakers extends BaseHullMod {

	public static float FLUX_RESISTANCE = 50f;
	public static float VENT_RATE_BONUS = 25f;

	public static float DISSIPATION_PENALTY = 0.9f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getVentRateMult().modifyPercent(id, VENT_RATE_BONUS);
		//stats.getEmpDamageTakenMult().modifyMult(id, 1f - FLUX_RESISTANCE * 0.01f);

		boolean sMod = isSMod(stats);
		//if (!sMod) {
		//	stats.getFluxDissipation().modifyMult(id, DISSIPATION_PENALTY);
		//}
		if (sMod) {
			stats.getEmpDamageTakenMult().modifyMult(id, 1f - FLUX_RESISTANCE * 0.01f);
		}
	}

	public String getSModDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) Math.round(FLUX_RESISTANCE) + "%";
		return null;
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		//if (index == 0) return "" + (int) FLUX_RESISTANCE + "%";
		if (index == 0) return "" + (int) VENT_RATE_BONUS + "%";
		//if (index == 2) return "" + (int)Math.round((1f - DISSIPATION_PENALTY) * 100f) + "%";
		return null;
	}


}
