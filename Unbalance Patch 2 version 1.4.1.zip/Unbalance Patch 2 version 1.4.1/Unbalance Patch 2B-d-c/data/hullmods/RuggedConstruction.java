package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class RuggedConstruction extends BaseHullMod {

	public static float DEPLOYMENT_COST_MULT = 0.5f;
	
//	public static float MIN_HULL = 30f;
//	public static float MAX_HULL = 40f;
//	
//	public static float MIN_CR = 30f;
//	public static float MAX_CR = 40f;
//	
//	public static float CR_LOSS_WHEN_DISABLED = 0.1f;
//	public static float REPAIR_FRACTION = 0.5f;
	
	//public static float DMOD_EFFECT_MULT = 0.5f;
	//public static float DMOD_AVOID_CHANCE = 50f;

	public static float MIN_ARMOR_BONUS = 0.1f;
	public static float BEAM_DAMAGE_REDUCTION = 0.5f;
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//stats.getDynamic().getStat(Stats.DMOD_EFFECT_MULT).modifyMult(id, DMOD_EFFECT_MULT);
		//stats.getDynamic().getMod(Stats.DMOD_AVOID_PROB_MOD).modifyFlat(id, DMOD_AVOID_CHANCE * 0.01f);
		//stats.getDynamic().getMod(Stats.DMOD_ACQUIRE_PROB_MOD).modifyMult(id, (1f - DMOD_AVOID_CHANCE * 0.01f));
		
		stats.getMinArmorFraction().modifyFlat(id, MIN_ARMOR_BONUS);
		stats.getBeamDamageTakenMult().modifyMult(id, BEAM_DAMAGE_REDUCTION);
		
		//stats.getSuppliesToRecover().modifyMult(id, DEPLOYMENT_COST_MULT);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		//if (index == 0) return "" + (int) Math.round((1f - DMOD_EFFECT_MULT) * 100f) + "%";
		//if (index == 1) return "" + (int) DMOD_AVOID_CHANCE + "%";
		//if (index == 2) return "" + (int) Math.round((1f - DEPLOYMENT_COST_MULT) * 100f) + "%";

		if (index == 0) return "" + (int) Math.round((MIN_ARMOR_BONUS) * 100f) + "%";
		if (index == 1) return "" + (int) Math.round((BEAM_DAMAGE_REDUCTION) * 100f) + "%";
		return null;
	}

	@Override
	public boolean affectsOPCosts() {
		return true; // probably intended even though it doesn't, actually -am
	}

}








