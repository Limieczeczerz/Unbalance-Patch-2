package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
//import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;
public class No_Bono {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("No Bono");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("no_bono", // unique id for star
				StarTypes.NEUTRON_STAR, // id in planets.json
				175f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		//StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
		//system.removeEntity(coronaPlugin.getEntity());
		system.addCorona(star, Terrain.PULSAR_BEAM,
				20000f, // radius outside planet
				25f, // burn level of "wind"
				0f, // flare probability
				3f // CR loss mult while in it
		);

		system.setLightColor(new Color(180, 215, 255)); // light color in entire system, affects all entities
		//system.setLightColor(new Color(230, 230, 255)); // light color in entire system, affects all entities

		PlanetAPI alone = system.addPlanet("alone", star, "Alone", "barren_castiron", 80, 120, 1500, 60);

		PlanetAPI planet_null = system.addPlanet("planet_null", star, "Null", "desert", 210, 160, 2800, 120);
		planet_null.setCustomDescriptionId("planet_null");
		//alone.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		//alone.getSpec().setGlowColor(new Color(180, 215, 255, 255));
		planet_null.getSpec().setAtmosphereColor(new Color(180, 215, 255, 255));
		planet_null.getSpec().setPlanetColor(new Color(250, 190, 180, 255));
		//alone.getSpec().setAtmospheretColor(new Color(250, 190, 180, 255));
		planet_null.getSpec().setTilt(30);
		planet_null.getSpec().setPitch(5);
		planet_null.getSpec().setAtmosphereThicknessMin(62f); // fix for aliasing issue on outward side of planet
		planet_null.getSpec().setUseReverseLightForGlow(true);
		planet_null.applySpecChanges();

		//SectorEntityToken null_lag = system.addTerrain(Terrain.ASTEROID_FIELD,
		//		new AsteroidFieldParams(
		//				400f, // min radius
		//				800f, // max radius
		//				10, // min asteroid count
		//				20, // max asteroid count
		//				8f, // min asteroid radius
		//				12f, // max asteroid radius
		//				null)); // null for default name
		//null_lag.setCircularOrbit(star, 210-80, 2800, 120);

		SectorEntityToken empty_1 = system.addCustomEntity("empty_1", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"pirates"); // faction
		empty_1.setCircularOrbitPointingDown(star, 210-80, 2800, 120);

		//SectorEntityToken null_lag2 = system.addTerrain(Terrain.ASTEROID_FIELD,
		//		new AsteroidFieldParams(
		//				400f, // min radius
		//				800f, // max radius
		//				10, // min asteroid count
		//				20, // max asteroid count
		//				8f, // min asteroid radius
		//				12f, // max asteroid radius
		//				null)); // null for default name
		//null_lag2.setCircularOrbit(star, 210+80, 2800, 120);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint_null", "Devoid");
		jumpPoint.setCircularOrbit(star, 210 + 80, 2800, 120);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		jumpPoint.setRelatedPlanet(planet_null);
		system.addEntity(jumpPoint);

		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 5500, 100, Terrain.RING, "Road to Chaos");
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 5550, 190, Terrain.RING, "Road to Chaos");
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 5750, 240, Terrain.RING, "Road to Chaos");

		//PlanetAPI forbidden = system.addPlanet("forbidden", star, "Forbidden", "ice_giant", 120, 260, 8900, 500);
		//system.addRingBand(forbidden, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 800, 120, Terrain.RING, "Road to Chaos");
		//system.addRingBand(forbidden, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1000, 120, Terrain.RING, "Road to Chaos");
		//system.addRingBand(forbidden, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1200, 150, Terrain.RING, "Road to Chaos");

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 6000, 300, Terrain.RING, "Road to Chaos");
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 6100, 290, Terrain.RING, "Road to Chaos");
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 6200, 340, Terrain.RING, "Road to Chaos");

		PlanetAPI fameless = system.addPlanet("fameless", star, "Fameless", "toxic_cold", 120, 200, 8900, 500);
		//fameless.setCustomDescriptionId("planet_fameless");

		SectorEntityToken empty_2 = system.addCustomEntity("empty_1", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"pirates"); // faction
		empty_2.setCircularOrbitPointingDown(star, 120-60, 8900, 500);

		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint_null", "Outer System Jump-point");
		jumpPoint2.setCircularOrbit(star, 120+60, 8900, 500);
		jumpPoint2.setStandardWormholeToHyperspaceVisual();
		jumpPoint.setRelatedPlanet(fameless);
		system.addEntity(jumpPoint2);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 4, // min/max entities to add
				12000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
