package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Moronia {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Moronia");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		//SectorEntityToken eos_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/eos_nebula.png",
		//		0, 0, // center of nebula
		//		system, // location to add to
		//		"terrain", "nebula", // "nebula_blue", // texture to use, uses xxx_map for map
		//		4, 4, StarAge.AVERAGE); // number of cells in texture

		PlanetAPI star = system.initStar("moronia", // unique id for this star
				"star_red_dwarf", // id in planets.json
				600f,		// radius (in pixels at default zoom)
				600, // corona radius, from star edge
				5f, // solar wind burn level
				1f, // flare probability
				2f); // cr loss mult

		//system.setLightColor(new Color(250, 142, 0)); // light color in entire system, affects all entities
		system.setLightColor(new Color(255, 175, 140)); // light color in entire system, affects all entities

		PlanetAPI farquaad = system.addPlanet("farquaad", star, "Farquaad", "gas_giant", 250-100, 300, 2400, 120);
		//farquaad.setCustomDescriptionId("planet_farquaad");
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						560, // terrain effect middle radius
						farquaad, // entity that it's around
						360f, // visual band start
						760f, // visual band end
						new Color(123, 95, 134, 40), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(190, 153, 247, 80),
						new Color(245, 174, 239, 80),
						new Color(170, 174, 245, 100),
						new Color(245, 174, 196, 100),
						new Color(149, 121, 160, 100),
						new Color(104, 69, 117),
						new Color(63, 32, 75)
				));
		field.setCircularOrbit(farquaad, 0, 0, 20);
		
		PlanetAPI charming = system.addPlanet("charming", star, "Charming", "toxic", -60, 100, 2400, 120);
		charming.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		charming.getSpec().setGlowColor(new Color(250, 142, 0,255));
		charming.getSpec().setUseReverseLightForGlow(true);
		charming.getSpec().setAtmosphereThicknessMin(62f); // fix for aliasing issue on outward side of planet
		charming.applySpecChanges();

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Inner System Jump-point");
		jumpPoint.setCircularOrbit( star, 50+30, 2700, 120);
		jumpPoint.setRelatedPlanet(farquaad);
		system.addEntity(jumpPoint);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 5470, 320f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 5560, 320f, null, null);
		system.addAsteroidBelt(star, 150, 5500, 340, 200, 250, Terrain.ASTEROID_BELT, "Ring of Dodskysset I");
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 6670, 820f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 6760, 720f, null, null);
		system.addAsteroidBelt(star, 150, 6700, 340, 200, 250, Terrain.ASTEROID_BELT, "Ring of Dodskysset II");

		SectorEntityToken abynit = system.addCustomEntity("abynit", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		abynit.setCircularOrbitPointingDown(star, 250, 6000, 120);

		SectorEntityToken stable_point = system.addCustomEntity("stable_point", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		stable_point.setCircularOrbitPointingDown(star, 250-199, 6000, 120);

		//PlanetAPI charming = system.addPlanet("charming", star, "Charming", "barren2", 250-100, 90, 6000, 420);

		PlanetAPI vaanita = system.addPlanet("vaanita", star, "Vaanita", "frozen1", 200, 140, 8900, 580);
		vaanita.setCustomDescriptionId("planet_vaanita");
		vaanita.setInteractionImage("illustrations", "vacuum_colony");
		vaanita.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		vaanita.getSpec().setGlowColor(new Color(245,181,34,255));
		vaanita.getSpec().setUseReverseLightForGlow(true);
		vaanita.getSpec().setRotation(1f);
		vaanita.applySpecChanges();

		//JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Meepo's Jump-point");
		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Vanitaa Jump-point");
		jumpPoint_extra.setCircularOrbit( star, 200+60, 8900, 580);
		jumpPoint_extra.setRelatedPlanet(vaanita);
		system.addEntity(jumpPoint_extra);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				4, 6, // min/max entities to add
				10000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds
		
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
