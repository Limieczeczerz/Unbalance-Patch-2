package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;

public class Canaan {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Canaan");
		LocationAPI hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		// create the star and generate the hyperspace anchor for this system
		// Canaan, the promised land.
		PlanetAPI canaan_star = system.initStar("canaan", // unique id for this star
				"star_yellow",  // id in planets.json
				600f, 		  // radius (in pixels at default zoom)
				600); // corona radius, from star edge

		system.setLightColor(new Color(110, 110, 155)); // light color in entire system, affects all entities
		//system.setLightColor(new Color(210, 210, 255)); // light color in entire system, affects all entities

		PlanetAPI khna = system.addPlanet("khna", canaan_star, "Khna", "toxic", 0, 110, 1500, 60);
		//khna.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		khna.getSpec().setPlanetColor(new Color(0,0,0,255));
		//khna.getSpec().setGlowColor(new Color(255,255,255,255));
		//khna.getSpec().setUseReverseLightForGlow(true);
		khna.getSpec().setAtmosphereThicknessMin(50);
		khna.getSpec().setAtmosphereThickness(0.5f);
		khna.getSpec().setAtmosphereColor(new Color(255, 255, 255, 255));
		khna.applySpecChanges();

		SectorEntityToken gad_loc = system.addCustomEntity(null, null, "sensor_array_makeshift", "luddic_church");
		gad_loc.setCircularOrbitPointingDown(canaan_star, 0, 2000, 60);

		system.addAsteroidBelt(canaan_star, 300, 3600, 1000, 30, 180, Terrain.ASTEROID_BELT, "Canaan Accretion Swarm");
		system.addAsteroidBelt(canaan_star, 600, 4600, 1000, 60, 200, Terrain.ASTEROID_BELT, "Canaan Accretion Swarm");
		//system.addAsteroidBelt(canaan_star, 1200, 5600, 1000, 90, 50, Terrain.ASTEROID_BELT, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 256f, 5100, 255f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 4900, 280f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 4700, 295f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 4500, 240f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 4300, 272f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 4100, 300f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 3900, 290f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 3700, 295f, null, null);
		system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 512f, 3300, 220f, null, null);
		//system.addRingBand(canaan_star, "misc", "rings_dust0", 512f, 2, Color.white, 256f, 3000, 190f, null, null);

		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4900, 280f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4800, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4700, 295f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4600, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4500, 240f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4400, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4300, 272f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4200, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4100, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 4000, 300f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 3900, 290f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 3800, 290f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 3700, 295f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 512f, 3600, 220f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 256f, 3500, 190f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 256f, 3400, 255f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 256f, 3300, 255f, Terrain.RING, "Canaan Accretion Swarm");
		//system.addRingBand(canaan_star, "misc", "rings_special0", 512f, 2, Color.white, 256f, 3200, 255f, Terrain.RING, "Canaan Accretion Swarm");

		// Add a gate.
		PlanetAPI gilead = system.addPlanet("gilead", canaan_star, "Gilead", "terran", 60, 140, 6500, 350);
		gilead.getSpec().setPitch(190.0f);
		gilead.getSpec().setPlanetColor(new Color(255,245,225,255));
		gilead.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		gilead.getSpec().setGlowColor(new Color(250,225,195,255));
		gilead.getSpec().setUseReverseLightForGlow(true);
		gilead.applySpecChanges();
		gilead.setCustomDescriptionId("planet_gilead");
		gilead.setInteractionImage("illustrations", "gilead");

		//PlanetAPI og = system.addPlanet("og", gilead, "Og", "lava", 0, 80, 400, 20);
		PlanetAPI og = system.addPlanet("og", gilead, "Og", "lava", 0, 75, 600, 30);
		og.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "barren03"));
		og.getSpec().setPlanetColor(new Color(235,255,245,255));
		og.getSpec().setGlowColor(new Color(0,0,0,0));
		//og.getSpec().setUseReverseLightForGlow(true);
		og.getSpec().setPitch(140.0f);
		og.applySpecChanges();

		og.setCustomDescriptionId("planet_og");

		SectorEntityToken relay = system.addCustomEntity("gilead_relay", // unique id
				"Gilead Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		relay.setCircularOrbitPointingDown(canaan_star, 0, 6500, 350);
			
			// L5
		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("gilead_jump", "Gilead Jump-point");
		jumpPoint1.setCircularOrbit( canaan_star, 60+60, 6500, 350);
		jumpPoint1.setRelatedPlanet(gilead);
		jumpPoint1.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint1);
			
		// and have asteroids on the other side, too. - L5 is behind
		SectorEntityToken canaanL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
					400f, // min radius
					800f, // max radius
					25, // min asteroid count
					45, // max asteroid count
					4f, // min asteroid radius 
					12f, // max asteroid radius
					"Canaan L4 Asteroids")); // null for default name
		canaanL4.setCircularOrbit(canaan_star, 60+60, 6500, 350);

		SectorEntityToken canaanL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						10, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Canaan L5 Asteroids")); // null for default name
		canaanL5.setCircularOrbit(canaan_star, 0, 6500, 350);

		SectorEntityToken canaanL3 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						25, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Canaan L3 Asteroids")); // null for default name
		canaanL3.setCircularOrbit(canaan_star, 240, 6500, 350);

		// Lagrangrian gate - embedd in some lovely asteroids? - L4 is ahead
		SectorEntityToken gate1 = system.addCustomEntity("canaan_gate", // unique id
				"Gate of Canaan", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate1.setCircularOrbit(system.getEntityById("canaan"), 240, 6500, 350);

		PlanetAPI gad = system.addPlanet("gad", canaan_star, "Gad", "gas_giant", 180, 320, 8500, 550);
		gad.getSpec().setPitch(100.0f);
		gad.getSpec().setPlanetColor(new Color(145,155,95,255));
		gad.getSpec().setCloudColor(new Color(45,55,0,255));
		//gad.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		//gad.getSpec().setUseReverseLightForGlow(true);
		gad.getSpec().setGlowColor(new Color(255,255,255,255));
		gad.applySpecChanges();

		system.addRingBand(gad, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1000, 40, Terrain.RING, null);
		system.addRingBand(gad, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 1000, 45, null, null);
		//system.addRingBand(gad, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1200, 45, Terrain.RING, null);
		//system.addRingBand(gad, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 1200, 50, null, null);
		//system.addRingBand(gad, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1400, 42, Terrain.RING, null);
		//system.addRingBand(gad, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 1400, 47, null, null);

		PlanetAPI asher = system.addPlanet("asher", gad, "Asher", "barren-desert", 60, 100, 700, 40);
		asher.getSpec().setTilt(95f);
		asher.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		asher.getSpec().setGlowColor(new Color(197,34,245,255));
		asher.getSpec().setUseReverseLightForGlow(true);
		asher.getSpec().setPlanetColor(new Color(155,155,155,255));
		asher.getSpec().setCloudColor(new Color(155,155,155,255));
		asher.getSpec().setIconColor(new Color(155,155,155,255));
		asher.applySpecChanges();
		asher.setCustomDescriptionId("planet_asher");

		// and have asteroids on the other side, too. - L5 is behind
		SectorEntityToken gadL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						25, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Gad L4 Asteroids")); // null for default name
		gadL4.setCircularOrbit(canaan_star, 180+55, 8500, 550);

		SectorEntityToken gadL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						25, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Gad L5 Asteroids")); // null for default name
		gadL5.setCircularOrbit(canaan_star, 180-55, 8500, 550);

		PlanetAPI reuben = system.addPlanet("reuben", canaan_star, "Reuben", "gas_giant", 180, 255, 11000, 620);
		reuben.getSpec().setPlanetColor(new Color(200,200,200,255));
		reuben.getSpec().setCloudColor(new Color(200,200,200,255));
		reuben.applySpecChanges();

		SectorEntityToken skoll_magfield = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400, // terrain effect band width
						500, // terrain effect middle radius
						reuben, // entity that it's around
						300, // visual band start
						700, // visual band end
						new Color(50, 20, 100, 10), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(190, 255, 140),
						new Color(230, 245, 190),
						new Color(255, 210, 245),
						new Color(195, 155, 255),
						new Color(145, 100, 230),
						new Color(120, 100, 230),
						new Color(110, 100, 250)));
		skoll_magfield.setCircularOrbit(reuben, 0, 0, 40);

		// and have asteroids on the other side, too. - L5 is behind
		SectorEntityToken reubenL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						25, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Reuben L4 Asteroids")); // null for default name
		reubenL4.setCircularOrbit(canaan_star, 180+45, 11000, 620);

		SectorEntityToken reubenL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						25, // min asteroid count
						45, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Reuben L5 Asteroids")); // null for default name
		reubenL5.setCircularOrbit(canaan_star, 180-45, 11000, 620);

		system.addRingBand(canaan_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 12000, 500, Terrain.RING, "Paddan Aram");
		system.addRingBand(canaan_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12000, 550, null, "Paddan Aram");
		system.addRingBand(canaan_star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 12200, 700, Terrain.RING, "Paddan Aram");
		system.addRingBand(canaan_star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 12400, 750, Terrain.RING, "Paddan Aram");

		PlanetAPI zilpah = system.addPlanet("zilpah", canaan_star, "Zilpah", "frozen", 50, 140, 13500, 720);

		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("zilpah_jump", "Fringe Jump-point");
		jumpPoint2.setCircularOrbit( canaan_star, 50+60, 13500, 720);
		jumpPoint2.setRelatedPlanet(zilpah);
		jumpPoint2.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint2);

		system.addRingBand(canaan_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 14000, 700, Terrain.RING, "Ur of the Chaldees");
		system.addRingBand(canaan_star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 14000, 750, null, "Ur of the Chaldees");
		system.addRingBand(canaan_star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 12700, 800, Terrain.RING, "Paddan Aram");
		system.addRingBand(canaan_star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 12900, 850, Terrain.RING, "Paddan Aram");

		PlanetAPI naphtali = system.addPlanet("naphtali", canaan_star, "Naphtali", "ice_giant", 55, 310, 15800, 870);

		system.addRingBand(naphtali, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 850, 50, Terrain.RING, null);
		system.addRingBand(naphtali, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 850, 55, null, null);
		system.addRingBand(naphtali, "misc", "rings_special0", 256f, 0, Color.white, 256f, 870, 70, null, null);
		system.addRingBand(naphtali, "misc", "rings_special0", 256f, 0, Color.white, 256f, 890, 75, Terrain.RING, null);
		system.addRingBand(naphtali, "misc", "rings_special0", 256f, 0, Color.white, 256f, 1070, 80, null, null);
		system.addRingBand(naphtali, "misc", "rings_special0", 256f, 0, Color.white, 256f, 1090, 85, Terrain.RING, null);

		Misc.initConditionMarket(naphtali);
		naphtali.getMarket().addCondition(Conditions.DECIVILIZED);
		naphtali.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		naphtali.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);

		naphtali.getMarket().addCondition(Conditions.VOLATILES_TRACE);
		naphtali.getMarket().addCondition(Conditions.DARK);
		naphtali.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		naphtali.getMarket().addCondition(Conditions.VERY_COLD);
		naphtali.getMarket().addCondition(Conditions.HIGH_GRAVITY);

		naphtali.setCustomDescriptionId("planet_naphtali");

		PlanetAPI bilhah = system.addPlanet("bilhah", canaan_star, "Bilhah", "frozen2", 55, 55, 17300, 870);

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, canaan_star, StarAge.YOUNG,
		//		1, 2, // min/max entities to add
		//		19000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		true); // whether to allow habitable worlds
		
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
