//Isirah.javapackage data.scripts.world.systems;
package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.util.Misc;
//import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
public class Isirah {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Isirah");
		LocationAPI hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI isirah_star = system.initStar("isirah", // unique id for this star
				StarTypes.BLUE_GIANT,  // id in planets.json
				1100f, 		  // radius (in pixels at default zoom)
				650); // corona radius, from star edge

		system.setLightColor(new Color(210, 230, 255)); // light color in entire system, affects all entities

		// giant lava world
		PlanetAPI isirah_b = system.addPlanet("sutr", isirah_star, "Surtr", "lava", 150, 100, 3000, 150);

		SectorEntityToken isirah_b_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						300, // terrain effect middle radius
						isirah_b, // entity that it's around
						100f, // visual band start
						500f, // visual band end
						new Color(100, 30, 50, 3), // base color
						3f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(165, 35, 135, 130),
						new Color(200, 30, 115, 150),
						new Color(220, 25, 100, 190),
						new Color(235, 25, 90, 240),
						new Color(240, 35, 80, 255),
						new Color(240, 65, 60),
						new Color(240, 90, 45)
				));
		isirah_b_field.setCircularOrbit(isirah_b, 0, 0, 10);

		SectorEntityToken isirah_loc1 = system.addCustomEntity(null, null, "sensor_array_makeshift", Factions.PERSEAN);
		isirah_loc1.setCircularOrbitPointingDown(isirah_star, 150-60, 3000, 150);

		SectorEntityToken isirah_b_L1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						6f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		isirah_b_L1.setCircularOrbit(isirah_star, 150-60, 3000, 150);

		SectorEntityToken isirah_loc2 = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.PERSEAN);
		isirah_loc2.setCircularOrbitPointingDown(isirah_star, 150+60, 3000, 150);

		SectorEntityToken isirah_b_L2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						6f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		isirah_b_L2.setCircularOrbit(isirah_star, 150+60, 3000, 150);
		
		// Gilling w/ Fjalar / Galar 
		PlanetAPI isirah_c = system.addPlanet("gilling", isirah_star, "Gilling", "lava", 270, 180, 5000, 380);
		PlanetAPI isirah_c1 = system.addPlanet("fjalar", isirah_c, "Fjalar", "lava_minor", 0, 50, 600, 30);
		PlanetAPI isirah_c2 = system.addPlanet("galar", isirah_c, "Galar", "barren", 27, 40, 980, 50);

		// Isirah Inner Jumppoint
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("isirah_jump", "Inner Jump-point");
		jumpPoint2.setCircularOrbit( system.getEntityById("isirah"), 270-45, 5000, 380);
		jumpPoint2.setRelatedPlanet(isirah_c);
		system.addEntity(jumpPoint2);

		PlanetAPI isirah_d = system.addPlanet("corb", isirah_star, "Corb", "water", 270+45, 90, 5000, 380);
		//Misc.initConditionMarket(isirah_d);
		//isirah_d.getMarket().addCondition(Conditions.ORE_RICH);
		//isirah_d.getMarket().addCondition(Conditions.RARE_ORE_RICH);
		isirah_d.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
		//isirah_d.getMarket().addCondition(Conditions.HIGH_GRAVITY);
		//isirah_d.getMarket().addCondition(Conditions.EXTREME_WEATHER);
		isirah_d.getMarket().addCondition(Conditions.ORGANICS_COMMON);
		isirah_d.getMarket().addCondition(Conditions.WATER_SURFACE);
		//isirah_d.getMarket().addCondition(Conditions.HABITABLE);
		isirah_d.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		isirah_d.getMarket().addCondition(Conditions.VERY_HOT);

		isirah_d.setCustomDescriptionId("planet_corb");

		//gebbar3.getSpec().setGlowColor(new Color(235, 195, 245, 255));
		isirah_d.getSpec().setPlanetColor(new Color(100,200,100,255));
		//gebbar3.getSpec().setAtmosphereColor(new Color(255,255,255,155));
		isirah_d.applySpecChanges();

		// Morn accretion cloud
		SectorEntityToken isirah_d1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						1000f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						4f, // min asteroid radius
						14f, // max asteroid radius
						"Corb Accretion Swarm")); // null for default name
		isirah_d1.setCircularOrbit(isirah_star, 270+45, 5000, 380);

		// Isirah Gate
		SectorEntityToken gate = system.addCustomEntity("isirah_gate", // unique id
				"Isirah Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction

		gate.setCircularOrbit(system.getEntityById("isirah"), 180-60, 7300, 450);

		PlanetAPI geirrod = system.addPlanet("geirrod", isirah_star, "Geirrod", "gas_giant", 180, 320, 7300, 450);
			
		// Utgarda Disk : "the outyards" 
		system.addRingBand(isirah_star, "misc", "rings_dust0", 		256f, 0, Color.white, 256f, 8200, 680f);
		system.addRingBand(isirah_star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 8400, 630f);
		system.addRingBand(isirah_star, "misc", "rings_dust0", 		256f, 1, Color.white, 256f, 8300, 625f);
		system.addRingBand(isirah_star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 8400, 650f);
		system.addRingBand(isirah_star, "misc", "rings_dust0", 		256f, 1, Color.white, 256f, 8500, 650f);
		system.addRingBand(isirah_star, "misc", "rings_asteroids0", 256f, 3, Color.white, 256f, 8600, 630f);
		system.addRingBand(isirah_star, "misc", "rings_dust0", 		256f, 1, Color.white, 256f, 8750, 680f);
		
		system.addAsteroidBelt(isirah_star, 100, 8300, 180, 200, 640, Terrain.ASTEROID_BELT, "Utgarda's Wall");
		system.addAsteroidBelt(isirah_star, 140, 8500, 180, 240, 660, Terrain.ASTEROID_BELT, "Utgarda's Wall");
		system.addAsteroidBelt(isirah_star, 80, 8700, 180, 280, 680, Terrain.ASTEROID_BELT, "Utgarda's Wall");

		PlanetAPI egdir = system.addPlanet("egdir", isirah_star, "Egdir", "ice_giant", 180, 400, 9800, 900);
		egdir.getSpec().setPlanetColor(new Color(50,0,0,255));
		//egdir.getSpec().setCloudRotation(10f);
		//egdir.getSpec().setAtmosphereThicknessMin(80);
		//egdir.getSpec().setAtmosphereThickness(0.1f);
		//egdir.getSpec().setAtmosphereColor(new Color(255,255,255,155));
		egdir.applySpecChanges();
		egdir.setCustomDescriptionId("planet_egdir");
		
		SectorEntityToken station1 = system.addCustomEntity("laicaille_habitat", "Laicaille Habitat", "station_side00", "persean");
		station1.setCustomDescriptionId("station_laicaille");
		station1.setInteractionImage("illustrations", "orbital");
		station1.setCircularOrbitWithSpin(isirah_star, 180+60, 9800, 900, -1f, -3f);

		SectorEntityToken egdir_L1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						6f, // min asteroid radius
						18f, // max asteroid radius
						null)); // null for default name
		egdir_L1.setCircularOrbit(isirah_star, 180+60, 9800, 900);
		
		SectorEntityToken station2 = system.addCustomEntity("station_kapteyn", "Kapteyn Starworks", "station_mining00", "pirates");
		station2.setCustomDescriptionId("station_kapteyn");
		station2.setInteractionImage("illustrations", "industrial_megafacility");
		//station2.setCircularOrbitPointingDown(system.getEntityById("isirah"), 180-60, 4300, 400);		
		station2.setCircularOrbitWithSpin(isirah_star, 180-60, 9800, 900, -1f, -3f);

		SectorEntityToken egdir_L2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						6f, // min asteroid radius
						18f, // max asteroid radius
						null)); // null for default name
		egdir_L2.setCircularOrbit(isirah_star, 180-60, 9800, 900);

		// Vosud Disc : "grandfather of winter"
		system.addRingBand(isirah_star, "misc", "rings_ice0", 		256f, 0, Color.white, 256f, 10700, 580f);
		system.addRingBand(isirah_star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 10800, 600f);
		system.addRingBand(isirah_star, "misc", "rings_ice0", 		256f, 1, Color.white, 256f, 10900, 600f);
		system.addRingBand(isirah_star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 11000, 600f);
		system.addRingBand(isirah_star, "misc", "rings_ice0",		256f, 2, Color.white, 256f, 11100, 630f);
		system.addRingBand(isirah_star, "misc", "rings_ice0",		256f, 1, Color.white, 256f, 11250, 680f);
		
		system.addAsteroidBelt(isirah_star, 400, 10800, 360, 600, 140, Terrain.ASTEROID_BELT, "Disk of Vosud");
		system.addAsteroidBelt(isirah_star, 320, 11100, 360, 640, 180, Terrain.ASTEROID_BELT, "Disk of Vosud");
		
		// Norvia: mother of night
		// & Nott : "night"	
		PlanetAPI isirah_e = system.addPlanet("norvia", isirah_star, "Norvia", "cryovolcanic", 270, 160, 12500, 1000);
		//isirah_e.setCustomDescriptionId("planet_norvia");
			PlanetAPI isirah_e1 = system.addPlanet("nott", isirah_e, "Nott", "frozen", 180, 60, 520, 30);
			//isirah_e1.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "frozen00"));
			//isirah_e1.applySpecChanges();

		JumpPointAPI jumpPoint3 = Global.getFactory().createJumpPoint("isirah_jump", "Outer Jump-point");
		jumpPoint3.setCircularOrbit( system.getEntityById("isirah"), 270-60, 12500, 1000);
		jumpPoint3.setRelatedPlanet(isirah_e);
		system.addEntity(jumpPoint3);
			
		SectorEntityToken station3 = system.addCustomEntity("groombridge_habitat", "Groombridge Habitat", "station_side00", "neutral");
		station3.setCustomDescriptionId("station_groombridge");
		station3.setInteractionImage("illustrations", "abandoned_station3");
		station3.setCircularOrbitPointingDown(isirah_star, 270+60, 12500, 1000);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, isirah_star, StarAge.YOUNG,
				3, 3, // min/max entities to add
				14000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds
		
		system.autogenerateHyperspaceJumpPoints(true, true);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);
	}
}
