package data.scripts.world.corvus;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

@SuppressWarnings("unchecked")
public class Corvus { // implements SectorGeneratorPlugin {

	public void generate(SectorAPI sector) {
		final StarSystemAPI system = sector.getStarSystem("Corvus");

		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		PlanetAPI star = system.initStar("corvus",
				"star_yellow",
				700f,
				500, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		//system.setLightColor(new Color(250, 150, 0));

		PlanetAPI corvusXa = system.addPlanet("namaru", star, "Namaru", "barren2", 80, 55, 1800, 70);

		PlanetAPI corvusXb = system.addPlanet("anunnaki", star, "Anunnaki", "lava", -50, 160, 1800, 70);
		SectorEntityToken anunnaki_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(200, // terrain effect band width
						300, // terrain effect middle radius
						corvusXb, // entity that it's around
						200, // visual band start
						400, // visual band end
						new Color(50, 20, 100, 15), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(140, 100, 235),
						new Color(180, 110, 210),
						new Color(150, 140, 190),
						new Color(140, 190, 210),
						new Color(90, 200, 170),
						new Color(65, 230, 160),
						new Color(20, 220, 70)
				));
		anunnaki_field.setCircularOrbit(corvusXb, 0, 0, 10);
		
	// Asharu
		PlanetAPI corvusI = system.addPlanet("asharu", star, "Asharu", "desert", 55, 100, 2600, 125);
		corvusI.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		corvusI.getSpec().setGlowColor(new Color(250, 150, 0, 255));
		corvusI.getSpec().setUseReverseLightForGlow(true);
		corvusI.applySpecChanges();
		corvusI.setCustomDescriptionId("planet_asharu");
		PlanetAPI corvusIa = system.addPlanet("Asharu2", corvusI, "Asharu II", "barren_castiron", 0, 40, 350, 15);
		
		//SectorEntityToken corvus_loc1 = system.addCustomEntity(null, null, "sensor_array_makeshift", Factions.HEGEMONY);
		//corvus_loc1.setCircularOrbitPointingDown(star, 55 + 60, 2600, 125);
		
		// Asharu abandoned station
		SectorEntityToken neutralStation = system.addCustomEntity("corvus_abandoned_station",
				"Abandoned Terraforming Platform", "station_side06", "neutral");
		
			neutralStation.setCircularOrbitPointingDown(system.getEntityById("asharu"), 45, 300, 30);		
			neutralStation.setCustomDescriptionId("asharu_platform");
			neutralStation.setInteractionImage("illustrations", "abandoned_station2");
			Misc.setAbandonedStationMarket("corvus_abandoned_station_market", neutralStation);
			neutralStation.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo().addMothballedShip(FleetMemberType.SHIP, "lasher_Assault", null);
		
		// Asharu stellar shade - out of orbit, settled in one of Asharu's lagrangian points 
		SectorEntityToken asharu_shade = system.addCustomEntity("asharu_shade", "Asharu Stellar Shade", "stellar_shade", "neutral");
		asharu_shade.setCircularOrbitPointingDown(system.getEntityById("corvus"), 55 + 60 + 10, 2600, 125);
		asharu_shade.setCustomDescriptionId("stellar_shade");

		// Outer system

		//PlanetAPI corvusIV = system.addPlanet("corvus_IV", star, "Somnus", "ice_giant", 55, 250, 3800, 160);
		//corvusIV.getSpec().setPlanetColor(new Color(57,121,169,255));
		//corvusIV.applySpecChanges();

		PlanetAPI corvusV = system.addPlanet("corvus_V", star, "Mors", "lava_minor", 38, 100, 3800, 160);
		corvusV.getSpec().setPlanetColor(new Color(220,245,255,255));
		corvusV.applySpecChanges();
		//system.addAsteroidBelt(corvusIV, 50, 300, 20, 10, 35, Terrain.ASTEROID_BELT, null);
		//system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 350, 35, null, null);

		// Jangala Jumppoint - L4 (ahead)
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("mors_jump", "Mors Jump-point");
		jumpPoint2.setCircularOrbit(system.getEntityById("corvus"), 38+180, 3800, 160);
		jumpPoint2.setRelatedPlanet(corvusV);

		jumpPoint2.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint2);

		SectorEntityToken field_d1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						200f, // min radius
						500f, // max radius
						8, // min asteroid count
						12, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		field_d1.setCircularOrbit(star, 38 + 80, 3800, 160);

		SectorEntityToken field_d2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						200f, // min radius
						500f, // max radius
						8, // min asteroid count
						12, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		field_d2.setCircularOrbit(star, 38 - 60, 3800, 160);

		SectorEntityToken field_d3 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						200f, // min radius
						500f, // max radius
						15, // min asteroid count
						22, // max asteroid count
						7f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		field_d3.setCircularOrbit(star, 38 + 5, 4400, 160);

		//Not-yet-named Asteroids // Let's try "Nemo"
		system.addAsteroidBelt(star, 180, 5400, 300, 300, 300, Terrain.ASTEROID_BELT,  "Nemo's Belt");
		system.addRingBand(star, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 5300, 310f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 3, Color.white, 256f, 5440, 290f, null, null);
		
	// Jangala 
		PlanetAPI corvusII = system.addPlanet("jangala", star, "Jangala", "jungle", 245, 150, 6300, 250);
		corvusII.setCustomDescriptionId("planet_jangala");
		corvusII.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		corvusII.getSpec().setGlowColor(new Color(250, 150, 0,255));
		corvusII.getSpec().setUseReverseLightForGlow(true);
		corvusII.applySpecChanges();
		
			// Jangala Station 
			SectorEntityToken hegemonyStation = system.addCustomEntity("corvus_hegemony_station",
					"Jangala Station", "station_jangala_type", "hegemony");
			
			hegemonyStation.setCircularOrbitPointingDown(system.getEntityById("jangala"), 45 + 180, 360, 30);		
			hegemonyStation.setCustomDescriptionId("station_jangala");
			
			// Jangala Relay - L5 (behind)
			SectorEntityToken relay = system.addCustomEntity("corvus_relay", // unique id
					 "Jangala Relay", // name - if null, defaultName from custom_entities.json will be used
					 "comm_relay_makeshift", // type of object, defined in custom_entities.json
					 "hegemony"); // faction
			relay.setCircularOrbitPointingDown(system.getEntityById("corvus"), 245-60, 6300, 250);
		
			// Jangala Jumppoint - L4 (ahead)
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jangala_jump", "Jangala Jump-point");
			jumpPoint.setCircularOrbit(system.getEntityById("corvus"), 245+60, 6300, 250);
			jumpPoint.setRelatedPlanet(corvusII);
			
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint);

		// Corvus Gate
		SectorEntityToken gate = system.addCustomEntity("jangala_gate", // unique id
				 "Corvus Gate", // name - if null, defaultName from custom_entities.json will be used
				 "inactive_gate", // type of object, defined in custom_entities.json
				 null); // faction
		gate.setCircularOrbit(system.getEntityById("corvus"), 250, 4800, 250);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 7300, 410f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 7540, 390f, Terrain.RING, null);
		
	// Barad system
		//SectorEntityToken corvusIII = system.addPlanet("barad", star, "Barad", "gas_giant", 200, 300, 7800, 400);
		// move further along orbit so it's not so close to Jangala on game start
		float baradAngle = 100;
		SectorEntityToken corvusIII = system.addPlanet("barad", star, "Barad", "gas_giant", baradAngle, 420, 10600, 600);
		
		// Barad magnetic field
		SectorEntityToken barad_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(corvusIII.getRadius() + 200f, // terrain effect band width 
						(corvusIII.getRadius() + 200f) / 2f, // terrain effect middle radius
						corvusIII, // entity that it's around
						corvusIII.getRadius() + 50f, // visual band start
						corvusIII.getRadius() + 50f + 250f, // visual band end
						new Color(50, 20, 100, 40), // base color
						0.5f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(140, 100, 235),
						new Color(180, 110, 210),
						new Color(150, 140, 190),
						new Color(140, 190, 210),
						new Color(90, 200, 170), 
						new Color(65, 230, 160),
						new Color(20, 220, 70)
				));
		barad_field.setCircularOrbit(corvusIII, 0, 0, 100);
		
			SectorEntityToken corvusIIIA = system.addPlanet("corvus_IIIa", corvusIII, "Garnir", "cryovolcanic", 135, 120, 1580, 60);
			corvusIIIA.setCustomDescriptionId("planet_barad_a");
			
			// Pirate Station
			SectorEntityToken pirateStation = system.addCustomEntity("corvus_pirate_station",
					"Garnir Extraction Depot", "station_lowtech1", "pirates");
			pirateStation.setCircularOrbitPointingDown(system.getEntityById("corvus_IIIa"), 45, 280, 40);
			pirateStation.setCustomDescriptionId("pirate_base_barad");
			pirateStation.setInteractionImage("illustrations", "pirate_station");
	
			system.addRingBand(corvusIII, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 950, 45, null, null);
			system.addAsteroidBelt(corvusIII, 50, 1000, 200, 50, 45, Terrain.ASTEROID_BELT, null);
			system.addRingBand(corvusIII, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 1050, 45, null, null);
			
			SectorEntityToken corvusIIIB = system.addPlanet("corvus_IIIb", corvusIII, "Warion", "barren", 235, 70, 1300, 60);
			// corvusIIIB.setInteractionImage("illustrations", "vacuum_colony");
				
			// Barad trojans - L4 leads, L5 follows; therefore L4 is + in orbit, L5 is - (Thanks Tartiflette.)
			SectorEntityToken baradL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						500f, // min radius
						700f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Barad L4 Asteroids")); // null for default name
			
			SectorEntityToken baradL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						500f, // min radius
						700f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Barad L5 Asteroids")); // null for default name
			
			baradL4.setCircularOrbit(star, baradAngle -60f, 10600, 600);
			baradL5.setCircularOrbit(star, baradAngle +60f, 10600, 600);
			
			
			SectorEntityToken corvus_loc3 = system.addCustomEntity(null, null, "stable_location", Factions.NEUTRAL);
			corvus_loc3.setCircularOrbitPointingDown(star, baradAngle +60f, 10600, 600);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				3, 3, // min/max entities to add
				13800, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds
			
	
		
		//SectorEntityToken nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
		//		"   xx " +
		//		"  xx x" +
		//		" xxxx " +
		//		"xxxxxx" +
		//		"  xx  " +
		//		"    x ",
		//		6, 6, // size of the nebula grid, should match above string
		//		"terrain", "nebula_amber", 4, 4, null));
		//nebula.getLocation().set(corvusII.getLocation().x + 1000f, corvusII.getLocation().y);
		//nebula.setCircularOrbit(star, 140f, 20000, 1000);

		//SectorEntityToken corvus_locADDED = system.addCustomEntity(null, null, "nav_buoy", Factions.HEGEMONY);
		//corvus_locADDED.getLocation().set(corvusII.getLocation().x + 1000f, corvusII.getLocation().y);
		//corvus_locADDED.(star, 140f, 20000, 1000);
		
		StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);
		
		system.autogenerateHyperspaceJumpPoints(true, true);
	}

	
}









