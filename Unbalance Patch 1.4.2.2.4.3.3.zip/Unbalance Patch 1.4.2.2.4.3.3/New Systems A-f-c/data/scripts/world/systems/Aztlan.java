package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

//import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
public class Aztlan {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Aztlan");
		//system.setType(StarSystemType.BINARY_FAR);
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		//system.getMemoryWithoutUpdate().set(MusicPlayerPluginImpl.MUSIC_SET_MEM_KEY, "music_combat");

		PlanetAPI aztlan_star = system.initStar("aztlan", // unique id for this star
				"star_yellow",  // id in planets.json
				700f, 		  // radius (in pixels at default zoom)
				500); // corona radius, from star edge

		//PlanetAPI aztlan_star = system.initStar("aztlan", // unique id for this star
		//		"star_red_dwarf", // id in planets.json
		//		650f,		// radius (in pixels at default zoom)
		//		600, // corona radius, from star edge
		//		5f, // solar wind burn level
		//		1f, // flare probability
		//		2f); // cr loss mult
		system.setLightColor(new Color(250, 142, 0)); // light color in entire system, affects all entities

		PlanetAPI aztlan1_a = system.addPlanet("chimalma", aztlan_star, "Chimalma", "rocky_metallic", -30, 100, 1500, 85);
		aztlan1_a.setCustomDescriptionId("planet_chimalma");

		PlanetAPI aztlan1 = system.addPlanet("xolotl", aztlan_star, "Xolotl", "lava_minor", 30, 150, 3500, 160);
		aztlan1.getSpec().setGlowColor(new Color(0,0,255,255));
		aztlan1.applySpecChanges();

		system.addRingBand(aztlan_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 4000, 220f, null, null);
		system.addRingBand(aztlan_star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 4100, 255f, null, null);
		system.addRingBand(aztlan_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4200, 240f, null, null);
		system.addAsteroidBelt(aztlan_star, 150, 4100, 256, 240, 160, Terrain.ASTEROID_BELT, "The Ciltetl");
		
	// Chicomoztoc & friends
		PlanetAPI aztlan2 = system.addPlanet("chicomoztoc", aztlan_star, "Chicomoztoc", "barren-desert", 60, 140, 5000, 200);
		aztlan2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		aztlan2.getSpec().setGlowColor(new Color(255,128,16,255));
		aztlan2.getSpec().setUseReverseLightForGlow(true);
		aztlan2.applySpecChanges();
		aztlan2.setCustomDescriptionId("planet_chicomoztoc");	
		aztlan2.setInteractionImage("illustrations", "urban03");
		
		system.addRingBand(aztlan2, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 400, 30f, null, null);
		system.addRingBand(aztlan2, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 400, 33f, Terrain.RING, null);
			
			SectorEntityToken hegemonyStation = system.addCustomEntity("aztlan_starport", "Aztlan Starport", "station_side05", "hegemony");
			hegemonyStation.setCircularOrbitPointingDown(system.getEntityById("chicomoztoc"), 0, 200, 10);
			hegemonyStation.setInteractionImage("illustrations", "orbital");
			//hegemonyStation.setCustomDescriptionId("station_jangala");

			PlanetAPI aztlan3b = system.addPlanet("zorrah", aztlan2, "Zorrah", "barren3", 30, 50, 600, 30);
			aztlan3b.setCustomDescriptionId("planet_zorrah");
		
			// Sensor Array in far orbit of Chicomoztoc
			SectorEntityToken aztlan_loc = system.addCustomEntity(null, null, "nav_buoy", Factions.HEGEMONY);
			aztlan_loc.setCircularOrbitPointingDown(aztlan_star, 240, 5000, 200);
			
			JumpPointAPI jumpPoint_aztlan = Global.getFactory().createJumpPoint("aztlan_jump_point_alpha", "Aztlan Inner System Jump-point");
			OrbitAPI orbit = Global.getFactory().createCircularOrbit(aztlan_star, 0, 5000, 200);
			jumpPoint_aztlan.setOrbit(orbit);
			jumpPoint_aztlan.setRelatedPlanet(aztlan2);
			jumpPoint_aztlan.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint_aztlan);

		// Aztlan Gate
		SectorEntityToken gate = system.addCustomEntity("aztlan_gate", // unique id
				"Aztlan Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(system.getEntityById("aztlan"), -30, 6200, 420);

		PlanetAPI aztlan4 = system.addPlanet("toci", aztlan_star, "Toci", "gas_giant", -30, 440, 7500, 420);
		//system.setSecondary(aztlan4);
		aztlan4.getSpec().setIconColor(new Color(154,135,136,255));
		aztlan4.getSpec().setPlanetColor(new Color(54,35,36,255));
		aztlan4.getSpec().setAtmosphereColor(new Color(181,29,35,255));
		aztlan4.getSpec().setAtmosphereThickness(0.5f);
		aztlan4.setCustomDescriptionId("planet_toci");

		aztlan4.getSpec().setCloudTexture(Global.getSettings().getSpriteName("hab_glows", "terran01"));
		aztlan4.getSpec().setCloudColor(new Color(181,29,35,50));
		aztlan4.getSpec().setCloudRotation(-2f);

		aztlan4.applySpecChanges();
		//system.addCorona(aztlan4, 300, 1f, 0f, 1f); // it's a very docile star.
		//PlanetAPI aztlan4 = system.addPlanet("toci", aztlan_star, "Toci", "gas_giant", -30, 440, 7500, 420);
		// duzahk_star magnetic field
		//SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
		//		new MagneticFieldParams(500f, // terrain effect band width
		//				1000, // terrain effect middle radius
		//				aztlan4, // entity that it's around
		//				750f, // visual band start
		//				1250f, // visual band end
		//				new Color(50, 20, 100, 40), // base color
		//				1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
		//				new Color(50, 20, 110, 130),
		//				new Color(150, 30, 120, 150),
		//				new Color(200, 50, 130, 190),
		//				new Color(250, 70, 150, 240),
		//				new Color(200, 80, 130, 255),
		//				new Color(75, 0, 160),
		///			new Color(127, 0, 255)
		//		));
		//field.setCircularOrbit(aztlan4, 0, 0, 50);
		
	// Tlalocan System
		PlanetAPI aztlan3 = system.addPlanet("tlalocan", aztlan_star, "Tlalocan", "ice_giant", 130, 290, 10500, 500);
		aztlan3.getSpec().setPlanetColor(new Color(255,210,170,255));
		aztlan3.getSpec().setPitch(20f);
		aztlan3.getSpec().setTilt(10f);
		aztlan3.applySpecChanges();
		
			// rocky ring system for Tlalocan
			system.addAsteroidBelt(aztlan3, 50, 630, 100, 30, 40, Terrain.ASTEROID_BELT, null);
			system.addRingBand(aztlan3, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 630, 43f, null, null);
			system.addRingBand(aztlan3, "misc", "rings_special0", 256f, 2, Color.white, 256f, 830, 53f, Terrain.RING, null);
			
			PlanetAPI aztlan3a = system.addPlanet("coatl", aztlan3, "Coatl", "barren-bombarded", 30, 80, 1250, 50);
			aztlan3a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "barren"));
			aztlan3a.getSpec().setGlowColor(new Color(200,225,255,255));
			aztlan3a.getSpec().setUseReverseLightForGlow(true);
			aztlan3a.applySpecChanges();
			aztlan3a.setCustomDescriptionId("planet_coatl");
			
			SectorEntityToken coatl_station = system.addCustomEntity("coatl_station", "Coatl Bastion", "station_side02", "hegemony");
			coatl_station.setCircularOrbitPointingDown(system.getEntityById("coatl"), 45, 200, 50);
			coatl_station.setCustomDescriptionId("station_coatl");
			coatl_station.setInteractionImage("illustrations", "hound_hangar");
			
			SectorEntityToken relay = system.addCustomEntity("aztlan_relay", // unique id
					 "Aztlan Relay", // name - if null, defaultName from custom_entities.json will be used
					 "comm_relay", // type of object, defined in custom_entities.json
					 "hegemony"); // faction
	
			relay.setCircularOrbitPointingDown( system.getEntityById("tlalocan"), 150, 1900, 500);
			relay.addTag(Tags.STORY_CRITICAL); // used by GAKallichore
		
		
		// L4 & L5 mini-nebulas
		SectorEntityToken tlalocan_L4_nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
				"  x   " +
				"  xx x" +
				"xxxxx " +
				" xxx  " +
				" x  x " +
				"   x  ",
				6, 6, // size of the nebula grid, should match above string
				"terrain", "nebula", 4, 4, null));
		
		SectorEntityToken tlalocan_L5_nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
				"  x   " +
				" xx xx" +
				"x  xx " +
				" xxxx " +
				" x x x" +
				"  x   ",
				6, 6, // size of the nebula grid, should match above string
				"terrain", "nebula", 4, 4, null));
		
		tlalocan_L5_nebula.setCircularOrbit(aztlan_star, 130 - 60, 10500, 500);
		tlalocan_L4_nebula.setCircularOrbit(aztlan_star, 130 + 60, 10500, 500);
		
		// and a jump point hidden in Tlalocan's L5.
		JumpPointAPI jumpPoint_aztlan2 = Global.getFactory().createJumpPoint("aztlan_jump_point_beta", "Aztlan Outer System Jump-point");
		OrbitAPI orbit2 = Global.getFactory().createCircularOrbit(aztlan_star, 130 + 60, 10500, 500);
		jumpPoint_aztlan2.setOrbit(orbit2);
		jumpPoint_aztlan2.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint_aztlan2);

		//system.addAsteroidBelt(aztlan_star, 100, 11000, 500, 600, 800, Terrain.ASTEROID_BELT, null);
		system.addRingBand(aztlan_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 13030, 530f, Terrain.RING, null);
		system.addRingBand(aztlan_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 13130, 630f, Terrain.RING, null);
		
		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, aztlan_star, StarAge.YOUNG,
		//		2, 4, // min/max entities to add
		//		14000, // radius to start adding at
		//		3, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds
		
		system.autogenerateHyperspaceJumpPoints(true, false);
	}
}
