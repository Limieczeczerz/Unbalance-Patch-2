package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

public class Deathcon {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Deathcon");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");

		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("deathcon", "black_hole", 900f, 0);
		StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
		system.removeEntity(coronaPlugin.getEntity());

		system.addCorona(star, Terrain.EVENT_HORIZON,
				1000f, // radius outside planet
				-10f, // burn level of "wind"
				0f, // flare probability
				5f // CR loss mult while in it
		);

		//system.setLightColor(new Color(250, 134, 67)); // light color in entire system, affects all entities
		system.setLightColor(new Color(99, 165, 165)); // light color in entire system, affects all entities

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.OLD,
				1, 1, // min/max entities to add
				3000, // radius to start adding at
				4, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		SectorEntityToken costomania = system.addCustomEntity("costomania", // unique id
				"Costomania", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		costomania.setCircularOrbitPointingDown(star, 150, 5500, 125);

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Deathcon Entrance");
		jumpPoint_extra.setCircularOrbit(star, -140, 8600, 400);
		system.addEntity(jumpPoint_extra);

		PlanetAPI gimli = system.addPlanet("gimli", star, "Gimli", "irradiated", -290, 110, 10500, 520);
		gimli.setCustomDescriptionId("planet_gimli");
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(100f, // terrain effect band width
						160, // terrain effect middle radius
						gimli, // entity that it's around
						110f, // visual band start
						210f, // visual band end
						new Color(189, 179, 57, 10), // base color
						0.5f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(125, 152, 37, 30),
						new Color(196, 182, 59, 50),
						new Color(255, 206, 77, 90),
						new Color(255, 240, 117, 140),
						new Color(184, 184, 72, 155),
						new Color(186, 150, 24),
						new Color(156, 143, 20)
				));
		field.setCircularOrbit(gimli, 0, 0, 10);

		SectorEntityToken meridia = system.addCustomEntity("meridia", "Ghost of Meridia", "station_hightech3", "tritachyon");
		meridia.setCircularOrbitPointingDown(system.getEntityById("gimli"), 30, 330, 30);
		meridia.setCustomDescriptionId("station_meridia");
		meridia.setInteractionImage("illustrations", "cargo_loading");

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14500, 850, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 15800, 800, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 16200, 820, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 18500, 950, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 19800, 900, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 20000, 820, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 20800, 1000, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 21000, 820, Terrain.RING, null);

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				"Rollerblade", // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		don_eladio.setCircularOrbitPointingDown(star, -290+90, 10500, 520);

		//SectorEntityToken don_eladio_2 = system.addCustomEntity("don_eladio_2", // unique id
		//		"Obisidian Communicatory", // name - if null, defaultName from custom_entities.json will be used
		//		"comm_relay", // type of object, defined in custom_entities.json
		//		"tritachyon"); // faction
		//don_eladio_2.setCircularOrbitPointingDown(star, -120, 20600, 820);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
