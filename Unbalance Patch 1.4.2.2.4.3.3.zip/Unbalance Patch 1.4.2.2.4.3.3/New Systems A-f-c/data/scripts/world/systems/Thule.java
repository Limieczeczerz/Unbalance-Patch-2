package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.util.Misc;

public class Thule {

	public void generate(SectorAPI sector) {	
		
		StarSystemAPI system = sector.createStarSystem("Thule");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI thule_star = system.initStar("thule", // unique id for this star
												"star_white",  // id in planets.json
												600f, 		  // radius (in pixels at default zoom)
												600, // corona
												4f, // solar wind burn level
												0.5f, // flare probability
												1.5f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(200, 230, 255)); // light color in entire system, affects all entities
		
		PlanetAPI hekla = system.addPlanet("hekla", thule_star, "Hekla", "toxic", 0, 100, 1370, 60);
		hekla.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		hekla.getSpec().setGlowColor(new Color(255,190,10,100));
		hekla.getSpec().setUseReverseLightForGlow(true);
		//hekla.getSpec().setPlanetColor(new Color(55, 55, 55, 255));
		//hekla.getSpec().setCloudTexture(Global.getSettings().getSpriteName("hab_glows", "terran03"));
		//hekla.getSpec().setCloudColor(new Color(155, 155, 0, 50));
		//hekla.getSpec().setAtmosphereColor(new Color(155, 155, 0, 255));
		hekla.applySpecChanges();

		system.addAsteroidBelt(thule_star, 90, 2100, 350, 100, 60, Terrain.RING,  "Earls of Lade");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, new Color(100,100,100,255), 256f, 2000, 110f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, new Color(100,100,100,255), 256f, 2120, 130f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, new Color(100,100,100,255), 256f, 2200, 110f, null, null);

		PlanetAPI kazeron = system.addPlanet("kazeron", thule_star, "Kazeron", "barren_castiron", 90, 130, 3200, 225);
		kazeron.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		kazeron.getSpec().setGlowColor( new Color(240,215,117,255) );
		kazeron.getSpec().setUseReverseLightForGlow(true);
		kazeron.getSpec().setPitch(-15f);
		kazeron.getSpec().setTilt(20f);
		kazeron.applySpecChanges();
		kazeron.setCustomDescriptionId("planet_kazeron");
		kazeron.setInteractionImage("illustrations", "kazeron");

		system.addAsteroidBelt(thule_star, 90, 3900, 300, 200, 160, Terrain.ASTEROID_BELT,  "The Ingwin");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3800, 205f, null, null);
		system.addRingBand(thule_star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 3920, 215f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4000, 205f, null, null);

		//SectorEntityToken kazeronStation = system.addCustomEntity("kazeron_station", "Kazeron Star Command", "station_midline2", Factions.PERSEAN);
		//kazeronStation.setCircularOrbitPointingDown( kazeron, 0, 250, 30);
		//kazeronStation.setInteractionImage("illustrations", "orbital");

		PlanetAPI draugr = system.addPlanet("draugr", kazeron, "Draugr", "toxic", 0, 40, 320, 24);
		//draugr.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		//draugr.getSpec().setGlowColor(new Color(255,220,50,235));
		//draugr.getSpec().setUseReverseLightForGlow(true);
		draugr.getSpec().setPitch(-45f);
		draugr.getSpec().setTilt(45f);
		//draugr.getSpec().setPlanetColor(new Color(240,240,255,255));
		//draugr.getSpec().setCloudColor(new Color(240,240,255,255));
		//draugr.getSpec().setAtmosphereColor(new Color(240,240,255,255));
		//draugr.getSpec().setIconColor(new Color(240,240,255,255));
		draugr.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "venus"));
		draugr.applySpecChanges();

		// Kazeron jump-point
		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("thule_jump", "Thule Jump-point");
		jumpPoint1.setCircularOrbit( system.getEntityById("thule"), 30, 3200, 225);
		jumpPoint1.setRelatedPlanet(kazeron);
		system.addEntity(jumpPoint1);

		SectorEntityToken kazeronL1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						500f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						10f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		kazeronL1.setCircularOrbit(thule_star, 30, 3200, 225);

		// Kazeron Relay - L5 (behind)
		SectorEntityToken kazeron_relay = system.addCustomEntity("kazeron_relay", "Kazeron Relay",  "comm_relay_makeshift", Factions.PERSEAN);
		kazeron_relay.setCircularOrbitPointingDown( thule_star, 150, 3200, 225);

		SectorEntityToken kazeronL2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						500f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						10f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		kazeronL2.setCircularOrbit(thule_star, 150, 3200, 225);

		system.addAsteroidBelt(thule_star, 90, 5880, 400, 450, 300, Terrain.RING,  "Inged's Crown");
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 5800, 405f, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 5900, 305f, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 6020, 365f, null, null);

		PlanetAPI eldfell = system.addPlanet("eldfell", thule_star, "Eldfell", "barren2", 180, 90, 5000, 360);
		eldfell.getSpec().setCloudTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		eldfell.getSpec().setCloudColor(new Color(225,195,130,145));
		eldfell.getSpec().setCloudRotation(1.5f);
		eldfell.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		eldfell.getSpec().setGlowColor(new Color(250,220,210,245));
		eldfell.getSpec().setUseReverseLightForGlow(true);
		eldfell.getSpec().setPitch(20f);
		eldfell.getSpec().setTilt(30f);
		//eldfell.getSpec().setPlanetColor(new Color(225,195,130,255));
		eldfell.getSpec().setAtmosphereThicknessMin(8);
		eldfell.getSpec().setAtmosphereThickness(0.07f);
		eldfell.getSpec().setAtmosphereColor(new Color(130,145,155,130));
		eldfell.applySpecChanges();
		eldfell.setCustomDescriptionId("planet_eldfell");

		PlanetAPI laki = system.addPlanet("laki", thule_star, "Laki", "barren3", 0, 30, 6300, 450);

		system.addAsteroidBelt(thule_star, 90, 6550, 250, 390, 310, Terrain.ASTEROID_BELT,  "Hama's Band");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 6500, 405f, null, null);
		system.addRingBand(thule_star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 6600, 395f, null, null);

		PlanetAPI hengill = system.addPlanet("hengill", thule_star, "Hengill", "frozen2", 180, 110, 9700, 560);

		//Eldfell jump-point
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("eldfell_jump", "Outer System Jump-point");
		jumpPoint2.setCircularOrbit(system.getEntityById("thule"), 180+180, 9700, 560);
		//jumpPoint2.setRelatedPlanet(hengill);
		system.addEntity(jumpPoint2);

		// Gate of Thule
		SectorEntityToken gate = system.addCustomEntity("thule_gate", // unique id
				"Gate of Thule", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction

		gate.setCircularOrbit(thule_star, 180+60, 9700, 560);
				
		SectorEntityToken eldfell_stable = system.addCustomEntity(null, null, "stable_location", "neutral");
		eldfell_stable.setCircularOrbitPointingDown( thule_star, 180-60 , 9700, 560);
				
		system.addAsteroidBelt(thule_star, 90, 10700, 400, 500, 300, Terrain.RING,  "Garmund's Ring");
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, new Color(230,240,255,255), 256f, 10600, 550, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 10750, 565, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 10750, 585, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, new Color(230,240,255,255), 256f, 10870, 595, null, null);

		//SectorEntityToken thule_pirate_station = system.addCustomEntity("thule_pirate_station",
		//		"Thulian Raider Base", "station_side02", "pirates");

		SectorEntityToken thule_pirate_station = system.addCustomEntity("thule_pirate_station", "Thulian Raider Base", "station_midline2", "pirates");
		thule_pirate_station.setCircularOrbitPointingDown(thule_star, 240, 12090, 638);
		thule_pirate_station.setCustomDescriptionId("station_thulian_raiders");
		thule_pirate_station.setInteractionImage("illustrations", "pirate_station");

		system.addRingBand(thule_star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 11410, 638f, Terrain.RING, "Puffin Islands");
		system.addRingBand(thule_star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 11510, 655f, Terrain.RING, "Puffin Islands");
		system.addRingBand(thule_star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 11610, 625f, Terrain.RING, "Puffin Islands");
		system.addRingBand(thule_star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 11710, 685f, Terrain.RING, "Puffin Islands");
		system.addRingBand(thule_star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 11810, 655f, Terrain.RING, "Puffin Islands");
		
		PlanetAPI skoll = system.addPlanet("skoll", thule_star, "Skoll", "ice_giant", 270, 260, 16450, 720);
		//skoll.setCustomDescriptionId("planet_skoll");
		skoll.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		skoll.getSpec().setGlowColor( new Color(50,255,250,75) );
		skoll.getSpec().setUseReverseLightForGlow(true);
		skoll.getSpec().setPitch(150f);
		skoll.getSpec().setTilt(80f);
		skoll.getSpec().setPlanetColor( new Color(150,150,150,255) );
		skoll.applySpecChanges();

		//SectorEntityToken array1 = system.addCustomEntity(null, null, "sensor_array", Factions.PIRATES);
		//array1.setCircularOrbitPointingDown(thule_star, 270 + 60, 16450, 720);
		//No array
		
			SectorEntityToken skoll_magfield = system.addTerrain(Terrain.MAGNETIC_FIELD,
			new MagneticFieldParams(400, // terrain effect band width
					500, // terrain effect middle radius
					skoll, // entity that it's around
					300, // visual band start
					700, // visual band end
					new Color(50, 20, 100, 50), // base color
					2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
					new Color(90, 180, 40),
					new Color(130, 145, 90),
					new Color(165, 110, 145), 
					new Color(95, 55, 160), 
					new Color(45, 0, 130),
					new Color(20, 0, 130),
					new Color(10, 0, 150)));
			skoll_magfield.setCircularOrbit(skoll, 0, 0, 20);

		PlanetAPI morn = system.addPlanet("morn", skoll, "Morn", "ice_giant", 90, 140, 1150, 90);
		morn.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		morn.getSpec().setGlowColor( new Color(235,250,150,45) );
		morn.getSpec().setUseReverseLightForGlow(true);
		morn.getSpec().setPitch(-5f);
		morn.getSpec().setTilt(20f);
		morn.getSpec().setPlanetColor(new Color(155, 155, 155, 255));
		morn.applySpecChanges();
		morn.setCustomDescriptionId("planet_morn");

		Misc.initConditionMarket(morn);
		morn.getMarket().addCondition(Conditions.LOW_GRAVITY);
		morn.getMarket().addCondition(Conditions.EXTREME_WEATHER);
		morn.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		morn.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
		morn.getMarket().addCondition(Conditions.VERY_COLD);
		morn.getMarket().addCondition(Conditions.DARK);

		// Kazeron jump-point
		//JumpPointAPI jumpPoint10 = Global.getFactory().createJumpPoint("thule_jump", "Fringe Jump-point");
		//jumpPoint10.setCircularOrbit( system.getEntityById("thule"), 90-45, 16450, 720);
		//system.addEntity(jumpPoint10);

		//SectorEntityToken kazeronStation = system.addCustomEntity("kazeron_station", "Kazeron Star Command", "station_midline2", Factions.PERSEAN);
		//kazeronStation.setCircularOrbitPointingDown( kazeron, 0, 250, 30);
		//kazeronStation.setInteractionImage("illustrations", "orbital");

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, thule_star, StarAge.AVERAGE,
		//		1, 3, // min/max entities to add
		//		13000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		true); // whether to allow habitable worlds
		
		system.autogenerateHyperspaceJumpPoints(true, false);
	}
}
