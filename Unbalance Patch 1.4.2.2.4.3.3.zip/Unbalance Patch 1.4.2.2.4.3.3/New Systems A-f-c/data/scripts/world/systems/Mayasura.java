package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
public class Mayasura {

	public void generate(SectorAPI sector) {

		StarSystemAPI system = sector.createStarSystem("Mayasura");
		LocationAPI hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI mayasura_star = system.initStar("mayasura",
				"star_yellow",
				800f,
				500, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(255, 245, 205)); // light color in entire system, affects all entities

		PlanetAPI mayasura_b = system.addPlanet("kasyapa", mayasura_star, "Kasyapa", "barren", 0, 90, 1550, 36);
		//mayasura_b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		//mayasura_b.getSpec().setGlowColor(new Color(255,150,50,50));
		//mayasura_b.getSpec().setUseReverseLightForGlow(true);
		//mayasura_b.getSpec().setAtmosphereThicknessMin(16);
		//mayasura_b.getSpec().setAtmosphereThickness(0.14f);
		//mayasura_b.getSpec().setAtmosphereColor( new Color(150,125,100,30));
		//mayasura_b.applySpecChanges();

		PlanetAPI mayasura_c = system.addPlanet("gelan", mayasura_star, "Gelan", "toxic", 300, 200, 2400, 87);
		mayasura_c.setCustomDescriptionId("planet_gelan");
		mayasura_c.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		mayasura_c.getSpec().setGlowColor(new Color(55,125,170,255));
		mayasura_c.getSpec().setUseReverseLightForGlow(true);
		mayasura_c.getSpec().setCloudColor(new Color(115,115,170,220));
		mayasura_c.getSpec().setPlanetColor(new Color(115,115,170,220));
		mayasura_c.getSpec().setAtmosphereThicknessMin(62f); // fix for aliasing issue on outward side of planet
		mayasura_c.applySpecChanges();

			//system.addRingBand(mayasura_c, "misc", "rings_special0", 256f, 0, new Color(255,230,100,255), 256f, 320, 15f, Terrain.RING, "Gelan's Shackle");

		// Mayasura Jumppoint in the L-something of Gelan
		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("mayasura_jump", "Mayasura Jump-point");
		jumpPoint.setCircularOrbit( mayasura_star, 300 + 60, 2400, 87);
		jumpPoint.setRelatedPlanet(mayasura_c);
		system.addEntity(jumpPoint);


		PlanetAPI mayasura_d = system.addPlanet("mairaath", mayasura_star, "Mairaath", "desert", 0, 100, 3800, 183);
		mayasura_d.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "desert01"));
		mayasura_d.getSpec().setPlanetColor(new Color(255,210,225,255));
		mayasura_d.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		mayasura_d.getSpec().setGlowColor(new Color(255,250,200,80));
		mayasura_d.getSpec().setUseReverseLightForGlow(true);

		mayasura_d.applySpecChanges();

		mayasura_d.setCustomDescriptionId("planet_mairaath");
		mayasura_d.setInteractionImage("illustrations", "mairaath");


			// Mairaath gets 1 orbiting derelict station, one lost station, and ideally plenty of debris
			SectorEntityToken mairaathStation1 = system.addCustomEntity("mairaath_abandoned_station1",
				"Abandoned Astropolis", "station_side06", "neutral");

			mairaathStation1.setCircularOrbitPointingDown( system.getEntityById("mairaath"), 45, 250, 25);

			Misc.setAbandonedStationMarket("mairaath_abandoned_station1_market", mairaathStation1);

			mairaathStation1.setCustomDescriptionId("mairaath_station1");
			mairaathStation1.setInteractionImage("illustrations", "abandoned_station3");

			// Mairaath stellar shade - out of orbit
			SectorEntityToken mairaath_shade = system.addCustomEntity("mairaath_shade", "Shade Chah", "stellar_shade", "neutral");
			mairaath_shade.setCircularOrbitPointingDown( mayasura_star, 300, 3550, 183 );
			mairaath_shade.setCustomDescriptionId("stellar_shade");

			// pirate sensor array counter-rotating Mairaath
			SectorEntityToken mayasura_stable1 = system.addCustomEntity(null, null, "sensor_array_makeshift", Factions.PIRATES);
			mayasura_stable1.setCircularOrbitPointingDown(mayasura_star, 180, 3800, 183);

		system.addAsteroidBelt(mayasura_star, 90, 4300, 200, 140, 180, Terrain.ASTEROID_BELT, "The Danavas");
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4360, 160f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 4260, 160f);


			// Pirates took over the lost station
			SectorEntityToken pirateStation = system.addCustomEntity("mairaath_abandoned_station2",
					"Lost Astropolis", "station_side06", "pirates");

			pirateStation.setCircularOrbitPointingDown(system.getEntityById("mayasura"), 45, 4500, 250);
			pirateStation.setCustomDescriptionId("mairaath_station2");
			pirateStation.setInteractionImage("illustrations", "pirate_station");

			// Debris for the Lost Astropolis
			DebrisFieldParams params = new DebrisFieldParams(
							150f, // field radius - should not go above 1000 for performance reasons
							-1f, // density, visual - affects number of debris pieces
							10000000f, // duration in days
							0f); // days the field will keep generating glowing pieces
			params.source = DebrisFieldSource.MIXED;
			params.baseSalvageXP = 500; // base XP for scavenging in field
			SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
			SalvageSpecialAssigner.assignSpecialForDebrisField(debris);

			// makes the debris field always visible on map/sensors and not give any xp or notification on being discovered
			debris.setSensorProfile(null);
			debris.setDiscoverable(null);

			// makes it discoverable and give 200 xp on being found
			// sets the range at which it can be detected (as a sensor contact) to 2000 units
			// commented out.
			//debris.setDiscoverable(true);
			//debris.setDiscoveryXP(200f);
			//debris.setSensorProfile(1f);
			//debris.getDetectedRangeMod().modifyFlat("gen", 2000);

			debris.setCircularOrbit(mayasura_star, 45 + 10, 4500, 250);


			// a gate opposite of the Lost Astropolis
			SectorEntityToken gate = system.addCustomEntity("mayasura_gate", // unique id
					 "Mayasura Gate", // name - if null, defaultName from custom_entities.json will be used
					 "inactive_gate", // type of object, defined in custom_entities.json
					 null); // faction

			gate.setCircularOrbit(system.getEntityById("mayasura"), 45 + 180, 4520, 250);

		PlanetAPI mayasura_e_a = system.addPlanet("diti", mayasura_star, "Aditi", "gas_giant", 180, 280, 6200, 420);
		//mayasura_e_a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		//mayasura_e_a.getSpec().setGlowColor(new Color(255,50,240,245));
		//mayasura_e_a.getSpec().setUseReverseLightForGlow(true);
		mayasura_e_a.getSpec().setPitch(-15f);
		//mayasura_e_a.getSpec().setTilt(40);
		mayasura_e_a.getSpec().setPlanetColor(new Color(255,240,235));
		mayasura_e_a.applySpecChanges();

		system.addRingBand(mayasura_e_a, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 600, 25, Terrain.RING, null);
		system.addRingBand(mayasura_e_a, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 600, 30, null, null);
		system.addRingBand(mayasura_e_a, "misc", "rings_special0", 256f, 2, Color.white, 256f, 700, 35, Terrain.RING, null);
		system.addRingBand(mayasura_e_a, "misc", "rings_special0", 256f, 2, Color.white, 256f, 800, 40, Terrain.RING, null);

		PlanetAPI mayasura_e_a_1 = system.addPlanet("adityas ", mayasura_star, "Adityas", "barren3", 180-60, 66, 6200, 420);
		mayasura_e_a_1.setCustomDescriptionId("planet_adityas");
		PlanetAPI mayasura_e_a_2 = system.addPlanet("bhaga ", mayasura_star, "Bhaga", "barren2", 180+60, 63, 5700, 420);
		PlanetAPI mayasura_e_a_3 = system.addPlanet("varuna ", mayasura_star, "Varuna", "lava_minor", 180+180, 77, 6200, 420);
		SectorEntityToken skoll_magfield = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(80, // terrain effect band width
						120, // terrain effect middle radius
						mayasura_e_a_3, // entity that it's around
						80, // visual band start
						160, // visual band end
						new Color(255, 255, 255, 5), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(190, 180, 40),
						new Color(230, 245, 90),
						new Color(165, 210, 145),
						new Color(195, 155, 160),
						new Color(145, 100, 130),
						new Color(120, 100, 130),
						new Color(110, 100, 150)));
		skoll_magfield.setCircularOrbit(mayasura_e_a_3, 0, 0, 10);

		PlanetAPI kashyap = system.addPlanet("kashyap", mayasura_star, "Kashyap", "toxic_cold", 270, 66, 8000, 580);
		kashyap.getSpec().setGlowColor(new Color(245,155,110,255));
		kashyap.getSpec().setPlanetColor(new Color(245,155,110));
		kashyap.getSpec().setAtmosphereColor(new Color(245,155,110,255));
		SectorEntityToken skoll_magfield2 = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(80, // terrain effect band width
						120, // terrain effect middle radius
						kashyap, // entity that it's around
						70, // visual band start
						150, // visual band end
						new Color(255, 255, 0, 5), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(190, 180, 0),
						new Color(230, 245, 0),
						new Color(165, 210, 0),
						new Color(195, 155, 0),
						new Color(145, 100, 0),
						new Color(120, 100, 0),
						new Color(110, 100, 0)));
		skoll_magfield2.setCircularOrbit(kashyap, 0, 0, 10);

		PlanetAPI mayasura_e = system.addPlanet("diti", mayasura_star, "Diti", "ice_giant", 270, 240, 9200, 580);
		mayasura_e.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		mayasura_e.getSpec().setGlowColor(new Color(255,50,240,245));
		mayasura_e.getSpec().setUseReverseLightForGlow(true);
		mayasura_e.getSpec().setPitch(15f);
		mayasura_e.getSpec().setTilt(40);
		mayasura_e.getSpec().setPlanetColor(new Color(255,240,235));
		mayasura_e.applySpecChanges();

			// rumoured to have the finest cocktail lounge in the entire Sector
			SectorEntityToken tritachStation = system.addCustomEntity("port_tse", "Port Tse Franchise Station", "station_side00", "tritachyon");
			tritachStation.setCustomDescriptionId("station_tse_enterprise");
			tritachStation.setInteractionImage("illustrations", "space_bar");
			tritachStation.setCircularOrbitWithSpin(mayasura_e, 60, 610, 30, 3, 5);

			PlanetAPI mayasura_e1 = system.addPlanet("arjun", mayasura_e, "Arjun's World", "rocky_unstable", 0, 60, 610, 30);
			mayasura_e1.getSpec().setAtmosphereThicknessMin(16);
			mayasura_e1.getSpec().setAtmosphereThickness(0.2f);
			mayasura_e1.getSpec().setAtmosphereColor( new Color(160,175,200,10) );
			mayasura_e1.getSpec().setPlanetColor(new Color(200,240,255));
			mayasura_e1.applySpecChanges();

		system.addRingBand(mayasura_e, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 800, 40, Terrain.RING, null);

		// Mayasura Relay
		SectorEntityToken mayasura_relay = system.addCustomEntity("mayasura_relay", "Mayasura Relay", "comm_relay_makeshift", "tritachyon");
		mayasura_relay.setCircularOrbitPointingDown( mayasura_star, 270 + 60, 9200, 580);

		// stable loc in counter-orbit to Diti
		SectorEntityToken mayasura_stable2 = system.addCustomEntity(null, null, "stable_location", Factions.NEUTRAL);
		mayasura_stable2.setCircularOrbitPointingDown(mayasura_star, 90, 9200, 580);

		SectorEntityToken mayasura_stable2_lagrange = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						8f, // min asteroid radius
						15f, // max asteroid radius
						"Diti L3 Asteroids")); // null for default name
		mayasura_stable2_lagrange.setCircularOrbit(mayasura_star, 90, 9200, 580);

		// planetoid ring jumppoint. God, I wish my life had meaning
		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumppoint_extra", "Outer System Jump-point");
		jumpPoint_extra.setCircularOrbit(mayasura_star, 44, 10900, 670);
		system.addEntity(jumpPoint_extra);

		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 10900, 620f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 11000, 590f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 11100, 600f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 11200, 550f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 11300, 550f);
		system.addRingBand(mayasura_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 11400, 555f);
		system.addAsteroidBelt(mayasura_star, 240, 11130, 600, 400, 600, Terrain.ASTEROID_BELT, "The Daitya");

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, mayasura_star, StarAge.AVERAGE,
		//		2, 3, // min/max entities to add
		//		13000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, false);
	}
}
