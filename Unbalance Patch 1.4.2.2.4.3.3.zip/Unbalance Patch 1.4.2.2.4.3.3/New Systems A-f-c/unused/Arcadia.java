package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

public class Arcadia {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Arcadia");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");
		
		//system.getMemoryWithoutUpdate().set(MusicPlayerPluginImpl.MUSIC_SET_MEM_KEY, "music_title");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("arcadia", // unique id for star
				StarTypes.WHITE_DWARF, // id in planets.json
				180f,		// radius (in pixels at default zoom)
				300); // corona radius, from star edge

		system.setLightColor(new Color(200, 200, 200)); // light color in entire system, affects all entities
		//star.setCustomDescriptionId("star_white");

		if (StarSystemGenerator.random.nextFloat() > 0.5)  {
			StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);
		}

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, new Color(255,255,200,255), 256f, 1000, 550f, Terrain.RING, null);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				3, 3, // min/max entities to add
				2000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		PlanetAPI arcadia1 = system.addPlanet("nomios", star, "Nomios", "frozen", 180, 80, 6800, 350);
		arcadia1.setCustomDescriptionId("planet_nomios");

		SectorEntityToken nomios_location = system.addCustomEntity(null, null, "nav_buoy",Factions.INDEPENDENT);
		nomios_location.setCircularOrbitPointingDown(star, 90 + 60, 6800, 350);

		PlanetAPI arcadia2 = system.addPlanet("syrinx", star, "Syrinx", "ice_giant", 90, 350, 8800, 450);
		arcadia2.setCustomDescriptionId("planet_syrinx");

			// Moon of syrinx w/ ship-wrecking & industrial stuff
			PlanetAPI arcadia2a = system.addPlanet("agreus", arcadia2, "Agreus", "barren-bombarded", 90+40, 80, 1200, 70);
			arcadia2a.setInteractionImage("illustrations", "industrial_megafacility"); // TODO something better for this.
			arcadia2a.setCustomDescriptionId("planet_agreus");

			system.addRingBand(arcadia2, "misc", "rings_special0", 256f, 0, new Color(200,210,255,255), 256f, 800, 40f, Terrain.RING, null);

			SectorEntityToken arc_station = system.addCustomEntity("arcadia_station", "Citadel Arcadia", "station_side02", "hegemony");
			arc_station.setCircularOrbitPointingDown(system.getEntityById("syrinx"), 45, 800, 40);
			arc_station.setCustomDescriptionId("station_arcadia");
			arc_station.setInteractionImage("illustrations", "hound_hangar");
		
			// lagrangian point of Syrinx
			SectorEntityToken relay = system.addCustomEntity("syrinx_relay", // unique id
					 "Syrinx Relay", // name - if null, defaultName from custom_entities.json will be used
					 "comm_relay_makeshift", // type of object, defined in custom_entities.json
					 "independent"); // faction
			relay.setCircularOrbitPointingDown( system.getEntityById("arcadia"), 90-40, 8800, 450);
			
			// lagrangian point of Syrinx
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("syrinx_passage","Syrinx Passage");
			OrbitAPI orbit = Global.getFactory().createCircularOrbit(star, 90+40, 8800, 450);
			jumpPoint.setOrbit(orbit);	
			jumpPoint.setRelatedPlanet(arcadia2a);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(0,210,255,255), 256f, 11500, 750f, Terrain.RING, null);

		PlanetAPI aphroditus = system.addPlanet("aphroditus ", star, "Aphroditus", "rocky_ice", -40, 140, 12800, 800);

		system.autogenerateHyperspaceJumpPoints(true, true);
		
		//system.addScript(new IndependentTraderSpawnPoint(sector, hyper, 1, 10, hyper.createToken(-6000, 2000), station));
	}
		
	
}
