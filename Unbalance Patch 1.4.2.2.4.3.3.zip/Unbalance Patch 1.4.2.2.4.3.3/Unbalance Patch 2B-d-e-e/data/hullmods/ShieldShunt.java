package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;

public class ShieldShunt extends BaseHullMod {

	//public static float EMP_RESISTANCE = 50f;
	//public static float VENT_RATE_BONUS = 50f;
	public static float ARMOR_BONUS = 25f;

	//public static float DMOD_EFFECT_MULT = 0.5f;
	
	//public static float DMOD_AVOID_CHANCE = 50f;


	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//stats.getVentRateMult().modifyPercent(id, VENT_RATE_BONUS);
		stats.getArmorBonus().modifyPercent(id, ARMOR_BONUS);
		//stats.getEmpDamageTakenMult().modifyMult(id, 1f - EMP_RESISTANCE * 0.01f);

		//stats.getDynamic().getStat(Stats.DMOD_EFFECT_MULT).modifyMult(id, DMOD_EFFECT_MULT);
		//stats.getDynamic().getMod(Stats.DMOD_AVOID_PROB_MOD).modifyFlat(id, DMOD_AVOID_CHANCE * 0.01f);
		//stats.getDynamic().getMod(Stats.DMOD_ACQUIRE_PROB_MOD).modifyMult(id, (1f - DMOD_AVOID_CHANCE * 0.01f));
	}

	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.setShield(ShieldType.NONE, 0f, 1f, 1f);
	}


	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ARMOR_BONUS + "%";
		//if (index == 1) return "" + (int) EMP_RESISTANCE + "%";
		//if (index == 2) return "" + (int) VENT_RATE_BONUS + "%";

		//if (index == 2) return "" + (int) DMOD_AVOID_CHANCE + "%";
		//if (index == 3) return "" + (int) Math.round((1f - DMOD_EFFECT_MULT) * 100f) + "%";
		return null;
	}

	public boolean isApplicableToShip(ShipAPI ship) {
		//if (ship.getVariant().hasHullMod(HullMods.CIVGRADE) &&
		//		!ship.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS)) return false;
		if (ship.getVariant().getHullSpec().getShieldType() == ShieldType.NONE &&
				!ship.getVariant().hasHullMod("frontshield")) return false;
		if (ship.getVariant().hasHullMod("shield_shunt")) return true;
		return ship != null && ship.getShield() != null;
	}

	public String getUnapplicableReason(ShipAPI ship) {
		//if (ship.getVariant().getHullSpec().getShieldType() == ShieldType.NONE) {
		//	return "Ship has no shields";
		//}
		//if (ship.getVariant().hasHullMod(HullMods.CIVGRADE) && !ship.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS)) {
		//	return "Can not be installed on civilian ships";
		//}
		//return null;
		return "Ship has no shields";
	}


}









