package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class HardenedShieldEmitter extends BaseHullMod {

	public static float PIERCE_MULT = 0.5f;
	public static float SHIELD_BONUS = 25f;

	//public static float SHIELD_MALUS = 5f;

	public static float UPKEEP_MALUS = 50f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BONUS * 0.01f);
		stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, PIERCE_MULT);

		boolean sMod = isSMod(stats);
		//stats.getShieldDamageTakenMult().modifyMult(id, 1f - (SHIELD_BONUS - (sMod ? SHIELD_MALUS : 0)) * 0.01f);

		if (sMod) {
			stats.getShieldUpkeepMult().modifyMult(id, 1f + UPKEEP_MALUS * 0.01f);
		}
	}

	@Override
	public String getSModDescriptionParam(int index, HullSize hullSize, ShipAPI ship) {
		if (index == 0) return "" + (int) UPKEEP_MALUS + "%";
		//if (index == 0) return "" + (int) SHIELD_MALUS + "%";
		return null;
	}

	@Override
	public boolean isSModEffectAPenalty() {
		return true;
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) SHIELD_BONUS + "%";
		return null;
	}

	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && ship.getShield() != null;
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		return "Ship has no shields";
	}

}
