package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Generosity {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Generosity");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("generosity", // unique id for this star
				"star_blue_supergiant",  // id in planets.json
				1500f,          // radius (in pixels at default zoom)
				1000, // corona radius, from star edge
				15f, // solar wind burn level
				3f, // flare probability
				2f); // cr loss mult
		
		system.setLightColor(new Color(82, 90, 117)); // light color in entire system, affects all entities

		//SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
		//		"Path to Greatness", // name - if null, defaultName from custom_entities.json will be used
		//		"nav_buoy", // type of object, defined in custom_entities.json
		//		"luddic_path"); // faction
		//don_eladio.setCircularOrbitPointingDown(star, 10, 2600, 100);

		PlanetAPI prion = system.addPlanet("prion", star, "Prion", "gas_giant", 120, 475, 5000, 240);
		prion.getSpec().setIconColor(new Color(135,153,139,255));
		prion.getSpec().setPlanetColor(new Color(35,54,40,255));
		prion.getSpec().setAtmosphereColor(new Color(29,181,69,255));
		prion.getSpec().setAtmosphereThickness(0.5f);
		prion.setCustomDescriptionId("planet_prion");

		prion.getSpec().setCloudTexture(Global.getSettings().getSpriteName("hab_glows", "terran01"));
		prion.getSpec().setCloudColor(new Color(29,181,69,50));
		prion.getSpec().setCloudRotation(-2f);

		prion.applySpecChanges();

		PlanetAPI lotus = system.addPlanet("lotus", star, "Forge of Lotus", "lava", 120, 95, 3800, 240);
		lotus.setCustomDescriptionId("planet_lotus");

		SectorEntityToken prion_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(180f, // terrain effect band width
						720, // terrain effect middle radius
						prion, // entity that it's around
						480f, // visual band start
						1080f, // visual band end
						new Color(82, 156, 255, 10), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(255, 195, 82, 30),
						new Color(255, 139, 82, 50),
						new Color(255, 215, 82, 90),
						new Color(255, 169, 82, 40),
						new Color(255, 236, 82, 55),
						new Color(117, 82, 160),
						new Color(82, 102, 255)
				));
		prion_field.setCircularOrbit(prion, 0, 0, 100);

		PlanetAPI event = system.addPlanet("event", star, "Event", "rocky_metallic", 400, 170, 8200, 370);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Babko Blitzkins Jump-Point");
		jumpPoint.setCircularOrbit( star, 80, 8200, 370);
		jumpPoint.setRelatedPlanet(event);
		system.addEntity(jumpPoint);

		PlanetAPI horbinos = system.addPlanet("horbinos", star, "Horbinos", "gas_giant", 120, 235, 8200, 370);
		
		PlanetAPI german_ghoul = system.addPlanet("german_ghoul", horbinos, "German Ghoul", "barren_venuslike", 0, 60, 700, 35);

		PlanetAPI tonderilla = system.addPlanet("tonderilla", horbinos, "Tonderilla", "barren2", 42, 80, 1050, 40);
		tonderilla.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		tonderilla.getSpec().setGlowColor(new Color(255,41,47,255));
		tonderilla.getSpec().setUseReverseLightForGlow(true);
		tonderilla.applySpecChanges();
		tonderilla.setCustomDescriptionId("planet_tonderilla");
		//tonderilla.setInteractionImage("illustrations", "urban00");
		
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 11500, 256f);
		system.addAsteroidBelt(star, 256, 11500, 256, 256, 256, Terrain.ASTEROID_BELT, null);

		SectorEntityToken don_eladio3 = system.addCustomEntity("don_eladio3", // unique id
				"Path to Blindness", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"luddic_path"); // faction
		don_eladio3.setCircularOrbitPointingDown(star, 250, 13200, 840);

		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint2", "Outer System Jump-Point");
		jumpPoint2.setCircularOrbit(star, 250-180, 13200, 840);
		//jumpPoint.setRelatedPlanet(event);
		system.addEntity(jumpPoint2);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				3, 5, // min/max entities to add
				14600, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
