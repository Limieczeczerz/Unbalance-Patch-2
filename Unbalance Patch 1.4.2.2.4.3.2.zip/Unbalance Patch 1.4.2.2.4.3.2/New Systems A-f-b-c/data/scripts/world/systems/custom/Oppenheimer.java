package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

public class Oppenheimer {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Oppenheimer");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("oppenheimer", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				475f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(143, 255, 197)); // light color in entire system, affects all entities

		//system is too crowded, removing these. Brown giant shouldn't have that much shit going on

		PlanetAPI nerma = system.addPlanet("nerma", star, "Nerma", "barren_castiron", 90, 115, 1500, 42);
		SectorEntityToken star_station = system.addCustomEntity("star_station", "Ster's Station", "station_side05", "hegemony");
		star_station.setCustomDescriptionId("planet_nerma");
		star_station.setCircularOrbitPointingDown(system.getEntityById("nerma"), 0, 250, 20);

		PlanetAPI false_prophet = system.addPlanet("false_prophet", star, "False Prophet", "lava_minor", 80-45, 120, 3000, 65);
		false_prophet.setCustomDescriptionId("planet_false_prophet");
		//Misc.initConditionMarket(false_prophet);
		//false_prophet.getMarket().addCondition(Conditions.RUINS_WIDESPREAD);
		//false_prophet.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
		//false_prophet.getMarket().addCondition(Conditions.ORE_MODERATE);
		//false_prophet.getMarket().addCondition(Conditions.EXTREME_WEATHER);
		//false_prophet.getMarket().addCondition(Conditions.TECTONIC_ACTIVITY);
		//false_prophet.getMarket().addCondition(Conditions.LOW_GRAVITY);
		//false_prophet.getMarket().addCondition(Conditions.HABITABLE);

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				"Jameson Vorhee's Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"hegemony"); // faction
		relay.setCircularOrbitPointingDown(system.getEntityById("oppenheimer"), -90, 4000, 110);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Dominator Jump-point");
		jumpPoint.setCircularOrbit(system.getEntityById("oppenheimer"), 150, 4800, 170);
		system.addEntity(jumpPoint);
		jumpPoint.setStandardWormholeToHyperspaceVisual();

		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 4000, 205f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 4100, 225f, Terrain.RING, null);

		PlanetAPI terra = system.addPlanet("terra", star, "Terra Non Benefacti", "frozen2", 110, 120, 6000, 324);

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 7600, 410f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 7700, 450f, null, null);
		system.addAsteroidBelt(star, 200, 7650, 200, 400, 250, Terrain.ASTEROID_BELT, null);

		// Askonia Gate
		SectorEntityToken gate = system.addCustomEntity("gate", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbitPointingDown(star, -145, 8000, 440);

		PlanetAPI jameson_vorhee = system.addPlanet("jameson_vorhee", star, "Jameson Vorhee", "ice_giant", 80, 240, 10000, 520);
		SectorEntityToken hybrasil_magfield = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400, // terrain effect band width
						480, // terrain effect middle radius
						jameson_vorhee, // entity that it's around
						240, // visual band start
						720, // visual band end
						new Color(45, 160, 135, 10), // base color
						0.5f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(225, 65, 10),
						new Color(225, 140, 10),
						new Color(225, 25, 10),
						new Color(225, 100, 10),
						new Color(10, 225, 175),
						new Color(10, 135, 225),
						new Color(10, 225, 28)));
		hybrasil_magfield.setCircularOrbit(jameson_vorhee, 0, 0, 20);

		SectorEntityToken L3 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		L3.setCircularOrbitPointingDown(system.getEntityById("oppenheimer"), 80-45, 10000, 520);

		SectorEntityToken L4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		L4.setCircularOrbitPointingDown(system.getEntityById("oppenheimer"), 80+45, 10000, 520);


		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
		//		1, 2, // min/max entities to add
		//		10000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		true); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, false);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
