package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Fanvorita {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Fanvorita");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("fanvorita", // unique id for star
				"star_red_dwarf", // id in planets.json
				400f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				5f, // solar wind burn level
				1f, // flare probability
				2f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(140, 255, 180)); // light color in entire system, affects all entities

		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.HEGEMONY);
		don_eladio.setCircularOrbitPointingDown( star, 90 + 60, 2200, 140);

		SectorEntityToken nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
						"xxx" +
						" xx" +
						"xxx",
				3, 3, // size of the nebula grid, should match above string
				"terrain", "nebula", 4, 4, "Zone"));
		nebula.setId("nebula");
		nebula.setCircularOrbit(star, 90-60, 2200, 140);

		// Moon of syrinx w/ ship-wrecking & industrial stuff
		PlanetAPI sobriety = system.addPlanet("sobriety", star, "Sobriety", "rocky_metallic", 90, 195, 2200, 140);
		sobriety.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		sobriety.getSpec().setGlowColor(new Color(183,250,191,100) );
		sobriety.getSpec().setUseReverseLightForGlow(true);
		sobriety.setCustomDescriptionId("planet_sobriety");
		sobriety.applySpecChanges();

		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						400, // terrain effect middle radius
						sobriety, // entity that it's around
						200f, // visual band start
						400f, // visual band end
						new Color(189, 79, 57, 10), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(125, 52, 37, 30),
						new Color(196, 82, 59, 50),
						new Color(255, 106, 77, 90),
						new Color(255, 140, 117, 140),
						new Color(184, 84, 72, 155),
						new Color(186, 50, 24),
						new Color(156, 43, 20)
				));
		field.setCircularOrbit(sobriety, 0, 0, 10);

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, new Color(170,210,255,255), 256f, 3000, 150f, null, null);
		system.addAsteroidBelt(star, 200, 3000, 128, 150, 800, Terrain.ASTEROID_BELT, "Field of Nuah");
		PlanetAPI tiny_person = system.addPlanet("tiny_person", star, "Tiny Person", "water", -180, 30, 2900, 160);
		tiny_person.setCustomDescriptionId("planet_tiny_person");

		PlanetAPI vengeance = system.addPlanet("vengeance", star, "Vengeance", "barren", 180+60, 105, 3500, 180);

		JumpPointAPI jump = Global.getFactory().createJumpPoint("jump", "Vengeance Jump-point");
		jump.setCircularOrbit(system.getEntityById("fanvorita"), 180, 3500, 180);
		jump.setRelatedPlanet(vengeance);
		jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jump);

		//PlanetAPI resendance = system.addPlanet("resendance", star, "Resendance", "rocky_ice", -180, 130, 5000, 275);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				2, 4, // min/max entities to add
				5000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
