package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;
//import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;

public class Syzygy {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Syzygy");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background_galatia.jpg");

		//if (Global.getSettings().getBoolean("factionsClaimUnpopulatedCoreSystems")) {
		//	system.getMemoryWithoutUpdate().set(MemFlags.CLAIMING_FACTION, Factions.LUDDIC_CHURCH);
		//}
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("syzygy", // unique id for star
				"star_browndwarf", // id in planets.json
				420f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		//system.setLightColor(new Color(176, 29, 155)); // light color in entire system, affects all entities
		system.setLightColor(new Color(180, 240, 150)); // light color in entire system, affects all entities

		PlanetAPI darth_idiot = system.addPlanet("darth_idiot", star, "Darth Idiot", "irradiated", -20, 200, 1600, 55);
		darth_idiot.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		darth_idiot.getSpec().setGlowColor(new Color(165,185,255,100));
		darth_idiot.getSpec().setUseReverseLightForGlow(true);
		darth_idiot.getSpec().setAtmosphereThickness(0.5f);
		darth_idiot.getSpec().setAtmosphereColor(new Color(165,185,255,100));
		darth_idiot.getSpec().setAtmosphereThickness(0.5f);
		darth_idiot.applySpecChanges();

		SectorEntityToken station_twelve = system.addCustomEntity("station_twelve", "Station 12", "station_side05", "neutral");
		station_twelve.setCircularOrbitPointingDown(system.getEntityById("darth_idiot"), -50, 300, 50);
		station_twelve.setCustomDescriptionId("station_twelve");
		station_twelve.setInteractionImage("illustrations", "harry");

		PlanetAPI abo = system.addPlanet("abo", darth_idiot, "Abo", "barren2", -300, 50, 560, 25);
		//used to check temperature

		SectorEntityToken buoy = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array_makeshift", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		buoy.setCircularOrbitPointingDown(star, -20-45, 1600, 55);

		PlanetAPI corporeal = system.addPlanet("corporeal", star, "Corporeal", "barren3", 120, 100, 2800, 105);

		//JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Gaygan Jump-Point");
		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Inner System Jump-Point");
		jumpPoint.setCircularOrbit(star, -20+45, 1600, 55);
		system.addEntity(jumpPoint);

		//system.addRingBand(star, "misc", "rings_ice0", 256f, 2, new Color(200, 200, 255), 256f, 3400, 225f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, new Color(200, 200, 255), 256f, 3400, 230f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, new Color(200, 200, 255), 256f, 3450, 180f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 3590, 210f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, new Color(200, 200, 255), 256f, 3650, 190f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 3700, 175f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 3820, 180f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, new Color(200, 200, 255), 256f, 3880, 220f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 4000, 310f, null, null);

		system.addAsteroidBelt(star, 400, 3700, 800, 200, 280, Terrain.RING, "Dancing Blight");

		PlanetAPI gagner = system.addPlanet("gagner", star, "Gagner", "frozen1", -100, 135, 5000, 280);
		gagner.setCustomDescriptionId("planet_gagner");
		gagner.setInteractionImage("illustrations", "industrial_megafacility");
		gagner.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		gagner.getSpec().setGlowColor(new Color(197,34,245,255));
		gagner.getSpec().setUseReverseLightForGlow(true);
		gagner.getSpec().setPitch(-20f);
		gagner.getSpec().setTilt(60f);
		gagner.applySpecChanges();

		PlanetAPI amnesia = system.addPlanet("amnesia", star, "Amnesia", "ice_giant", 100, 360, 6900, 400);
		amnesia.getSpec().setPitch(30);
		amnesia.getSpec().setTilt(18f);
		amnesia.getSpec().setRotation(8f);
		amnesia.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		amnesia.getSpec().setGlowColor(new Color(245,90,0,255));
		amnesia.getSpec().setUseReverseLightForGlow(true);
		amnesia.applySpecChanges();
		PlanetAPI memory = system.addPlanet("memory", amnesia, "Memory", "cryovolcanic", -40, 55, 650, 35);
		memory.setCustomDescriptionId("planet_memory");
		memory.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		memory.getSpec().setGlowColor(new Color(255,255,255,255));
		memory.getSpec().setUseReverseLightForGlow(true);
		memory.applySpecChanges();
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 940, 50f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1000, 55f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1080, 57f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1110, 65f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1160, 67f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1240, 80f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1010, 62f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1115, 64f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1230, 70f);
		system.addAsteroidBelt(amnesia, 0, 1050, 400, 300, 300, Terrain.RING, "Entrails");

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		relay.setCircularOrbitPointingDown(star, 100+50, 6900, 400);

		SectorEntityToken asteroid_field1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						1000f, // max radius
						10, // min asteroid count
						40, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		asteroid_field1.setCircularOrbit(star, 100+50, 6900, 400);

		SectorEntityToken asteroid_field2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						1000f, // max radius
						10, // min asteroid count
						40, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		asteroid_field2.setCircularOrbit(star, 100-50, 6900, 400);

		//JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Gaygan Jump-Point");
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint", "Outer System Jump-Point");
		jumpPoint2.setCircularOrbit(star, 100-50, 6900, 400);
		system.addEntity(jumpPoint2);

		PlanetAPI sobriety = system.addPlanet("sobriety", star, "Sobriety", "toxic_cold", 55, 120, 10000, 600);

		SectorEntityToken asteroid_field3 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						5, // min asteroid count
						20, // max asteroid count
						7f, // min asteroid radius
						14f, // max asteroid radius
						null)); // null for default name
		asteroid_field3.setCircularOrbit(star, 55+40, 10000, 600);

		SectorEntityToken pirateStation = system.addCustomEntity("new_bezonia", "New Bezonia", "station_side05", "pirates");
		pirateStation.setCustomDescriptionId("station_new_bezonia");
		pirateStation.setInteractionImage("illustrations", "pirate_station");
		pirateStation.setCircularOrbitWithSpin(star, 55+40, 10000, 600, 6, 10);

		SectorEntityToken asteroid_field4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						5, // min asteroid count
						20, // max asteroid count
						7f, // min asteroid radius
						14f, // max asteroid radius
						null)); // null for default name
		asteroid_field4.setCircularOrbit(star, 55-40, 10000, 600);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 10400, 750f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 10550, 650f, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 10600, 700f, null, null);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, new Color(200, 200, 255), 256f, 10600, 600f, null, null);
		system.addAsteroidBelt(star, 0, 10500, 400, 800, 600, Terrain.RING, "Myraa's Remnants");

		system.autogenerateHyperspaceJumpPoints(true, false);

		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
