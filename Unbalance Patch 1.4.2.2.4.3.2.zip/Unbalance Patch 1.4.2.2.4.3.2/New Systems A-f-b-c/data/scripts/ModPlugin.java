package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.LocationAPI;

// *sigh*
//import com.fs.starfarer.api.impl.campaign.ids.Terrain;

//import com.fs.starfarer.api.campaign.SectorAPI;
//import com.fs.starfarer.api.campaign.SectorEntityToken;
//import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
//import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
//import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
//import com.fs.starfarer.api.characters.ImportantPeopleAPI;
//import com.fs.starfarer.api.campaign.econ.MarketAPI;
//import com.fs.starfarer.api.characters.PersonAPI;
//import com.fs.starfarer.api.impl.campaign.ids.Factions;
//import com.fs.starfarer.api.impl.campaign.ids.Ranks;
//import com.fs.starfarer.api.impl.campaign.ids.Skills;
//import com.fs.starfarer.api.impl.campaign.ids.Commodities;
//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
//import com.fs.starfarer.api.campaign.PersonImportance;
//import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

//Gen 1
import data.scripts.world.systems.custom.Parkapec;
import data.scripts.world.systems.custom.Cappuccino;
import data.scripts.world.systems.custom.Morokoon;
import data.scripts.world.systems.custom.Syzygy;
//import data.scripts.world.systems.custom.Vancouver;
import data.scripts.world.systems.custom.Moronia;
import data.scripts.world.systems.custom.Abin_Cresc;
import data.scripts.world.systems.custom.No_Bono;

//Gen 2
//import data.scripts.world.systems.custom.Generosity;
//import data.scripts.world.systems.custom.Horozit;
//import data.scripts.world.systems.custom.Fanvorita;
//import data.scripts.world.systems.custom.Deathcon;
//import data.scripts.world.systems.custom.Oppenheimer;
import data.scripts.world.systems.custom.Bzabzen;
import data.scripts.world.systems.custom.Vobo;
//import data.scripts.world.systems.custom.Gigno_Oropara;
//import data.scripts.world.systems.custom.Rednick;
//import data.scripts.world.systems.custom.Obediah;

//Gen 3
//import data.scripts.world.systems.custom.Abaddon;
//import data.scripts.world.systems.custom.Macro_Tone;
public class ModPlugin extends BaseModPlugin {
   public void onNewGame() {

        //gen 1
        new Parkapec().generate(Global.getSector());
        new Cappuccino().generate(Global.getSector());
        new Morokoon().generate(Global.getSector());
        new Syzygy().generate(Global.getSector());
        //new Vancouver().generate(Global.getSector());
        new Moronia().generate(Global.getSector());
        new Abin_Cresc().generate(Global.getSector());
        new No_Bono().generate(Global.getSector());

        //gen 2
        //new Generosity().generate(Global.getSector());
        //new Horozit().generate(Global.getSector());
        //new Fanvorita().generate(Global.getSector());
        //new Deathcon().generate(Global.getSector());
        //new Oppenheimer().generate(Global.getSector());
        new Bzabzen().generate(Global.getSector());
        new Vobo().generate(Global.getSector());
        //new Gigno_Oropara().generate(Global.getSector());
        //new Rednick().generate(Global.getSector());
        //new Obediah().generate(Global.getSector());

        //gen 3
        //new Abaddon().generate(Global.getSector());
        //new Macro_Tone().generate(Global.getSector());

        LocationAPI hyper = Global.getSector().getHyperspace();

        SectorEntityToken self_exiled_label = hyper.addCustomEntity("self_exiled_label_id", null, "self_exiled_label", null);
        self_exiled_label.setFixedLocation(-21000, -9100);

        SectorEntityToken injustice_label = hyper.addCustomEntity("injustice_label_id", null, "injustice_label", null);
        injustice_label.setFixedLocation(-34000, 13000);

        //SectorEntityToken oetaru_label = hyper.addCustomEntity("oetaru_label_id", null, "oetaru_label", null);
        //oetaru_label.setFixedLocation(-33000, 15500);

        //SectorEntityToken sleeping_tiger_label = hyper.addCustomEntity("sleeping_tiger_label_id", null, "sleeping_tiger_label", null);
        //sleeping_tiger_label.setFixedLocation(-12000, -30800);
    }
}