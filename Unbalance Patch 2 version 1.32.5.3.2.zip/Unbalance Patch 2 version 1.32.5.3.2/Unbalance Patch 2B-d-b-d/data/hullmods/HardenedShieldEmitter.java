package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class HardenedShieldEmitter extends BaseHullMod {

	public static float PIERCE_MULT = 0.5f;
	public static float SHIELD_BONUS = 15f;

	public static float SMOD_SHIELD_MALUS = 5f;

	//private static final float RANGE_MULT = 0.85f;
	//private static final float FIGHTER_RATE = 25f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {

		//boolean sMod = isSMod(stats);
		//if (sMod) {
		//stats.getBallisticWeaponRangeBonus().modifyMult(id, RANGE_MULT);
		//	stats.getEnergyWeaponRangeBonus().modifyMult(id, RANGE_MULT);

		//	stats.getFighterRefitTimeMult().modifyPercent(id, FIGHTER_RATE);
		//}

		boolean sMod = isSMod(stats);
		stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BONUS * 0.01f + (sMod ? SMOD_SHIELD_MALUS * 0.01f : 0));

		//stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BONUS * 0.01f);

		stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, PIERCE_MULT);		
	}

	@Override
	public String getSModDescriptionParam(int index, HullSize hullSize, ShipAPI ship) {
	//	if (index == 0) return "" + (int) Math.round((1f - RANGE_MULT) * 100f) + "%";
	//	if (index == 1) return "" + (int) Math.round(FIGHTER_RATE) + "%";
		if (index == 0) return "" + (int) Math.round(SMOD_SHIELD_MALUS) + "%";
		return null;
	}

	@Override
	public boolean isSModEffectAPenalty() {
		return true;
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) SHIELD_BONUS + "%";
		return null;
	}

	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && ship.getShield() != null;
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		return "Ship has no shields";
	}

}
