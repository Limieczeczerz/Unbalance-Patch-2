package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
//import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Morokoon {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Morokoon");
		system.setType(StarSystemType.BINARY_FAR);
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		PlanetAPI star = system.initStar("morokoon",
				"star_yellow", 
				900f,
				800, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		//system.setLightColor(new Color(250, 236, 95));
		//system.setLightColor(new Color(255, 210, 220));

		SectorEntityToken empty_a = system.addCustomEntity("empty_a", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"persean"); // faction
		empty_a.setCircularOrbitPointingDown(system.getEntityById("morokoon"), 120, 3200, 150);

		PlanetAPI ignacy = system.addPlanet("ignacy", star, "Ignacy", "barren3", 60, 110, 3200, 150);

		SectorEntityToken gate = system.addCustomEntity("morokoon_gate", // unique id
				"Morokoon Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(system.getEntityById("ignacy"), 240, 500, 150);

		PlanetAPI gongon_goon = system.addPlanet("gongon_goon", star, "Gongon-Goon", "barren", -60, 30, 3900, 150);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4000, 220, null, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4060, 220, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4110, 220, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4200, 240, null, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4300, 200, null, null);
		system.addAsteroidBelt(star, 200, 4100, 400, 200, 100, Terrain.ASTEROID_BELT, "Arbiter of Solus");

		PlanetAPI yendore = system.addPlanet("yendore", star, "Yendore", "desert", 240, 150, 5500, 180);
		yendore.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		yendore.getSpec().setGlowColor(new Color(255,175,171,255));
		yendore.getSpec().setUseReverseLightForGlow(true);
		yendore.applySpecChanges();
		yendore.setCustomDescriptionId("planet_yendore");
		yendore.setInteractionImage("illustrations", "mine");
		system.addRingBand(yendore, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 400, 30f, Terrain.RING, "Aspa");
		PlanetAPI prygniwic = system.addPlanet("prygniwic", yendore, "Prygniwic", "lava_minor", 240, 60, 600, 26);

		JumpPointAPI outer_jump = Global.getFactory().createJumpPoint("inner_jump", "Parpatout Jump-point");
		outer_jump.setCircularOrbit(system.getEntityById("morokoon"), 240 - 80, 5500, 180);
		outer_jump.setRelatedPlanet(yendore);
		outer_jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(outer_jump);

		SectorEntityToken parpatout = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						800f, // min radius
						1000f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						6f, // min asteroid radius
						20f, // max asteroid radius
						"Nona Lagrange Le Parpatout")); // null for default name
		parpatout.setCircularOrbit(star, 240 - 80, 5500, 180);

		PlanetAPI dermit = system.addPlanet("dermit", star, "Dermit", "barren_castiron", 240+80, 50, 5500, 180);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7000, 460, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7050, 400, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7200, 420, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7300, 550, Terrain.RING, null);

		SectorEntityToken empty_c = system.addCustomEntity("empty_c", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array_makeshift", // type of object, defined in custom_entities.json
				"persean"); // faction
		empty_c.setCircularOrbitPointingDown(star, -144, 7700, 350);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 8000, 420, Terrain.RING, null);

		PlanetAPI arbakan = system.addPlanet("arbakan", star, "Arbakan", "cryovolcanic", 210, 160, 10000, 510);
		arbakan.setCustomDescriptionId("planet_arbakan");
		//Misc.initConditionMarket(arbakan);
		//arbakan.getMarket().addCondition(Conditions.DECIVILIZED);
		//arbakan.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		//arbakan.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);

		//arbakan.getMarket().addCondition(Conditions.RARE_ORE_MODERATE);
		//arbakan.getMarket().addCondition(Conditions.VOLATILES_TRACE);
		//arbakan.getMarket().addCondition(Conditions.ORGANICS_PLENTIFUL);
		//arbakan.getMarket().addCondition(Conditions.EXTREME_TECTONIC_ACTIVITY);
		//arbakan.getMarket().addCondition(Conditions.COLD);
		//arbakan.getMarket().addCondition(Conditions.HIGH_GRAVITY);

		SectorEntityToken arbakan_l1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						"Arbakan L1")); // null for default name
		arbakan_l1.setCircularOrbit(star, 210-45, 10000, 510);

		SectorEntityToken arbakan_l2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						"Arbakan L2")); // null for default name
		arbakan_l2.setCircularOrbit(star, 210+45, 10000, 510);

		JumpPointAPI arbakan_jump = Global.getFactory().createJumpPoint("arbakan_jump", "Arbakan Jump-point");
		arbakan_jump.setCircularOrbit(star, 210+45, 10000, 510);
		arbakan_jump.setRelatedPlanet(arbakan);
		arbakan_jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(arbakan_jump);

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 11500, 660f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11600, 500, null, null);
		system.addAsteroidBelt(star, 100, 11550, 300, 400, 300, Terrain.ASTEROID_BELT, "Kobayaati");

		PlanetAPI gogool = system.addPlanet("gogool", star, "Gogool", "star_browndwarf", 210, 450, 15000, 510);
		system.setSecondary(gogool);
		system.addCorona(gogool, 500, 1f, 0f, 1f);
		PlanetAPI carpenter_beirut = system.addPlanet("carpenter_beirut", gogool, "Carpenter Beirut", "barren-bombarded", 210, 100, 1600, 80);
		
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}

	
}









