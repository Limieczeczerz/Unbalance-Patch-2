package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;

public class RecoveryShuttles extends BaseHullMod {

	public static float CREW_LOSS_MULT = 0.25f;
	
	public static float SMOD_CREW_LOSS_MULT = 0.05f;

	public static float RATE_DECREASE_MODIFIER = 10f;
	public static float RATE_INCREASE_MODIFIER = 15f;
	
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getDynamic().getStat(Stats.REPLACEMENT_RATE_DECREASE_MULT).modifyMult(id, 1f - RATE_DECREASE_MODIFIER / 100f);
		stats.getDynamic().getStat(Stats.REPLACEMENT_RATE_INCREASE_MULT).modifyPercent(id, RATE_INCREASE_MODIFIER);

		boolean sMod = isSMod(stats);
		float mult = CREW_LOSS_MULT;
		if (sMod) mult = SMOD_CREW_LOSS_MULT; 
		stats.getDynamic().getStat(Stats.FIGHTER_CREW_LOSS_MULT).modifyMult(id, mult);
	}
		
	public String getSModDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ((1f - SMOD_CREW_LOSS_MULT) * 100f) + "%";
		return null;
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ((1f - CREW_LOSS_MULT) * 100f) + "%";
		if (index == 1) return "" + (int) RATE_DECREASE_MODIFIER + "%";
		if (index == 2) return "" + (int) RATE_INCREASE_MODIFIER + "%";
		return null;
	}
	
	public boolean isApplicableToShip(ShipAPI ship) {
		if (Misc.isAutomated(ship.getVariant())) return false;
		
		if (ship.getVariant().hasHullMod(HullMods.CONVERTED_HANGAR)) return true;
		
		//int bays = (int) ship.getMutableStats().getNumFighterBays().getBaseValue();
		int bays = (int) ship.getMutableStats().getNumFighterBays().getModifiedValue();
//		if (ship != null && ship.getVariant().getHullSpec().getBuiltInWings().size() >= bays) {
//			return false;
//		}
		return ship != null && bays > 0; 
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship != null && Misc.isAutomated(ship.getVariant())) {
			return "Can not be installed on automated ships";
		}
		return "Ship does not have fighter bays";
	}
}




