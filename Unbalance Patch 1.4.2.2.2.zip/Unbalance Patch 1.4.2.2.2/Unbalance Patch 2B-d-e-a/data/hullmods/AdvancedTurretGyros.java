package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class AdvancedTurretGyros extends BaseHullMod {

	public static float TURRET_SPEED_BONUS = 75f;
	
	public static float SMOD_BONUS = 15f;
	//public static float SMOD_BONUS_PER_SIZE = 5f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
		stats.getBeamWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
		
		boolean sMod = isSMod(stats);
		if (sMod) {
			stats.getDamageToMissiles().modifyPercent(id, SMOD_BONUS);
			stats.getDamageToFighters().modifyPercent(id, SMOD_BONUS);
			stats.getDamageToFrigates().modifyPercent(id, SMOD_BONUS);
		}
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) TURRET_SPEED_BONUS + "%";
		return null;
	}

	public String getSModDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) SMOD_BONUS + "%";
		return null;
	}
	
}
