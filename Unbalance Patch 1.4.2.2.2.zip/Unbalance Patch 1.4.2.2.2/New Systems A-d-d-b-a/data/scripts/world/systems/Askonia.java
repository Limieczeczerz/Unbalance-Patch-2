package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.ids.Entities;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.util.Misc;

public class Askonia {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Askonia");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
		//system.getMemoryWithoutUpdate().set(MusicPlayerPluginImpl.MUSIC_SET_MEM_KEY, "music_title");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("askonia", // unique id for this star 
				StarTypes.RED_GIANT, // id in planets.json
				1000f,		// radius (in pixels at default zoom)
				1500, // corona radius, from star edge
				5f, // solar wind burn level
				0.5f, // flare probability
				2f); // cr loss mult

		system.setLightColor(new Color(255, 210, 200)); // light color in entire system, affects all entities

		//system.setLightColor(new Color(250, 110, 105)); // light color in entire system, affects all entities

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);

		PlanetAPI a1_0 = system.addPlanet("nakhl", star, "Nakhl", "toxic", 0, 125, 2550, 120);
		a1_0.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		a1_0.getSpec().setGlowColor(new Color(255, 0, 0, 255));
		a1_0.getSpec().setPlanetColor(new Color(165, 220, 175, 255));
		a1_0.getSpec().setUseReverseLightForGlow(true);
		a1_0.applySpecChanges();
		
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(200f, // terrain effect band width
						200, // terrain effect middle radius
						a1_0, // entity that it's around
						140f, // visual band start
						340f, // visual band end
						new Color(155, 255, 255, 0), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(156, 255, 221, 30),
						new Color(156, 224, 255, 50),
						new Color(156, 255, 187, 90),
						new Color(255, 192, 156, 40),
						new Color(164, 191, 191, 55),
						new Color(156, 255, 255),
						new Color(170, 155, 146)
				));
		field.setCircularOrbit(a1_0, 0, 0, 15);

		// Askonia Gate
		SectorEntityToken askonia_gate = system.addCustomEntity("askonia_gate", // unique id
				"Askonia Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		askonia_gate.setCircularOrbit(star, 0-40, 2550, 120);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3570, 170f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 3660, 176f, null, null);
		system.addAsteroidBelt(star, 150, 3600, 170, 200, 250, Terrain.ASTEROID_BELT, "Grasp");

		PlanetAPI a1 = system.addPlanet("sindria", star, "Sindria", "rocky_metallic", 0, 120, 4400, 270);
		a1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		a1.getSpec().setGlowColor(new Color(255,255,255,255));
		a1.getSpec().setUseReverseLightForGlow(true);
		a1.applySpecChanges();
		a1.setCustomDescriptionId("planet_sindria");
		a1.setInteractionImage("illustrations", "sindria");

		system.addOrbitalJunk(a1,
				"orbital_junk", // from custom_entities.json
				30, // num of junk
				12, 20, // min/max sprite size (assumes square)
				225, // orbit radius
				70, // orbit width
				10, // min orbit days
				20, // max orbit days
				60f, // min spin (degress/day)
				360f); // max spin (degrees/day)

		SectorEntityToken station = system.addCustomEntity("diktat_cnc", "Command & Control", "station_side02", "sindrian_diktat");
		station.setCircularOrbitPointingDown(system.getEntityById("sindria"), 45, 300, 50);
		station.setInteractionImage("illustrations", "orbital");
		//station.setCustomDescriptionId("station_ragnar");

		SectorEntityToken sindria_relay = system.addCustomEntity("sindria_relay", // unique id
				"Sindria Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"sindrian_diktat"); // faction
		sindria_relay.setCircularOrbitPointingDown( system.getEntityById("askonia"), -60, 4400, 270);
		
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("askonia_jump_point_alpha", "Sindria Jump-point");
			//OrbitAPI orbit = Global.getFactory().createCircularOrbit(a1, 0, 4400, 270);
			//jumpPoint.setOrbit(orbit);
			jumpPoint.setRelatedPlanet(a1);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			jumpPoint.setCircularOrbit(system.getEntityById("askonia"), 60, 4400, 270);
			system.addEntity(jumpPoint);
		
		// And now, the outer system.
			system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 5070, 170f, null, null);
			system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 5160, 176f, null, null);
			system.addAsteroidBelt(star, 150, 5100, 170, 200, 250, Terrain.ASTEROID_BELT, "Stone River");

		// Salus nav buoy, in L5
		SectorEntityToken salus_nav = system.addCustomEntity(null, "Salus Navigation Buoy", "nav_buoy", Factions.DIKTAT);
		salus_nav.setCircularOrbitPointingDown(star, 230, 5660, 430);
		
	// Salus system
		PlanetAPI a2 = system.addPlanet("salus", star, "Salus", "gas_giant", 230, 350, 8350, 430);
		a2.setCustomDescriptionId("planet_salus");
		a2.getSpec().setPlanetColor(new Color(255,225,170,255));
		//a2.getSpec().setIconColor(new Color(255,225,170,255));
		a2.getSpec().setAtmosphereColor(new Color(160,110,45,140));
		a2.getSpec().setCloudColor(new Color(255,164,96,200));
		a2.getSpec().setTilt(15);
		a2.applySpecChanges();

		Misc.initConditionMarket(a2);
		a2.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
		//a2.getMarket().addCondition(Conditions.ORGANICS_PLENTIFUL);
		a2.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		a2.getMarket().addCondition(Conditions.HOT);
		a2.getMarket().addCondition(Conditions.HIGH_GRAVITY);

		
			PlanetAPI a2a = system.addPlanet("cruor", a2, "Cruor", "rocky_unstable", 45, 40, 700, 25);
			a2a.setInteractionImage("illustrations", "desert_moons_ruins");
			a2a.setCustomDescriptionId("planet_cruor");
			
			system.addAsteroidBelt(a2, 50, 1100, 128, 40, 80, Terrain.ASTEROID_BELT, "Opis Ring");
			system.addRingBand(a2, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 1100, 80f);
			system.addRingBand(a2, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1120, 90f);
			system.addRingBand(a2, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1100, 120f);
			
			SectorEntityToken opis_debris_cloud = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						200f, // min radius
						400f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
					"Opis Debris Cloud")); // null for default name
			opis_debris_cloud.setCircularOrbitPointingDown(system.getEntityById("salus"), 45, 1100, 60);
			
			PlanetAPI a2b = system.addPlanet("volturn", a2, "Volturn", "water", 110, 80, 1450, 75);
			a2b.setCustomDescriptionId("planet_volturn");
			a2b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
			a2b.getSpec().setGlowColor(new Color(255,255,255,255));
			a2b.getSpec().setUseReverseLightForGlow(true);
			a2b.applySpecChanges();
			a2b.setInteractionImage("illustrations", "volturn");
		
		// Nortia - Independent (Charterist) base - caught in Salus' L4
			PlanetAPI a3 = system.addPlanet("nortia", star, "Nortia", "barren-bombarded", 230 + 60, 50, 8350, 430);
			a3.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
			a3.getSpec().setGlowColor(new Color(255,255,255,255));
			a3.getSpec().setUseReverseLightForGlow(true);
			a3.applySpecChanges();
			a3.setInteractionImage("illustrations", "hound_hangar");
			a3.setCustomDescriptionId("planet_nortia");
			
			// Salus trojans
			SectorEntityToken salusL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						15, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Salus L4 Asteroids")); // null for default name
			
			SectorEntityToken salusL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
							400f, // min radius
							800f, // max radius
							15, // min asteroid count
							30, // max asteroid count
							4f, // min asteroid radius
							16f, // max asteroid radius
							"Salus L5 Asteroids")); // null for default name
			
			salusL4.setCircularOrbit(star, 230 + 60, 8350, 430);
			salusL5.setCircularOrbit(star, 230 - 60, 8350, 430);
			
			// Askonia Outer Jump (in Salus L5)
			JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("salus_jump", "Salus L5 Jump-point");
			jumpPoint2.setCircularOrbit(star, 230 - 60, 8350, 430);
			jumpPoint2.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint2);

		PlanetAPI a2_0a = system.addPlanet("semonia", star, "Semonia", "ice_giant", 230, 280, 11500, 660);
		//PlanetAPI a2_0a = system.addPlanet("semonia", star, "Semonia", "ice_giant", 230, 250, 14750, 960);
		SectorEntityToken field_1 = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						500, // terrain effect middle radius
						a2_0a, // entity that it's around
						300f, // visual band start
						700f, // visual band end
						new Color(245, 0, 115, 0), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(245, 10, 0, 30),
						new Color(245, 55, 0, 50),
						new Color(155, 0, 245, 90),
						new Color(235, 0, 245, 40),
						new Color(160, 55, 105, 55),
						new Color(0, 245, 145),
						new Color(185, 0, 245)
				));
		field_1.setCircularOrbit(a2_0a, 0, 0, 20);
		a2_0a.getSpec().setPlanetColor(new Color(255, 255, 100, 255));
		a2_0a.getSpec().setAtmosphereColor(new Color(100, 100, 200, 255));
		a2_0a.getSpec().setTexture( Global.getSettings().getSpriteName("planets", "volturn") );
		//a2_0a.getSpec().setIconColor(new Color(100, 255, 100, 255));
		a2_0a.getSpec().setCloudColor(new Color(255, 255, 255, 100));
		a2_0a.applySpecChanges();
		a2_0a.setCustomDescriptionId("planet_semonia");

		Misc.initConditionMarket(a2);
		a2_0a.getMarket().addCondition(Conditions.VOLATILES_TRACE);
		a2_0a.getMarket().addCondition(Conditions.EXTREME_WEATHER);
		a2_0a.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		a2_0a.getMarket().addCondition(Conditions.COLD);
		a2_0a.getMarket().addCondition(Conditions.HIGH_GRAVITY);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 13570, 700, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 13970, 770, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 12800, 750, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 13000, 750, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 13150, 820, Terrain.RING, null);

		PlanetAPI a2_0b = system.addPlanet("segetia", star, "Segetia", "ice_giant", 230, 250, 14750, 960);
		//system.addRingBand(a2_0b, "misc", "rings_special0", 256f, 1, Color.white, 256f, 800, 65, Terrain.RING, null);
		//system.addRingBand(a2_0b, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1000, 70, Terrain.RING, null);
		//system.addRingBand(a2_0b, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1200, 77, Terrain.RING, null);

		// Salus trojans
		SectorEntityToken segetiaL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						16f, // max asteroid radius
						null)); // null for default name

		SectorEntityToken segetiaL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						16f, // max asteroid radius
						null)); // null for default name

		segetiaL4.setCircularOrbit(star, 230 + 60, 14750, 960);
		segetiaL5.setCircularOrbit(star, 230 - 60, 14750, 960);

		PlanetAPI a4_a = system.addPlanet("bellavista", star, "Bellavista", "frozen1", 230 - 60, 100, 14750, 960);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 15800, 610f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 15800, 630f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 15800, 650f, Terrain.RING, "Dust Ring");

		//NEED MORE SPACE!!!
		//TOO HOT!!!
		//AAAAAAAAAAAAH TOO MUCH STUFF
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 16150, 650f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 16150, 690f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 16150, 710f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 16150, 730f, Terrain.RING, "Cloud Ring");

		//JumpPointAPI segetia_jump_point = Global.getFactory().createJumpPoint("segetia_jump_point", "Segetia L5 Jump-point");
		//OrbitAPI orbit = Global.getFactory().createCircularOrbit(a1, 0, 4400, 270);
		//jumpPoint.setOrbit(orbit);
		//jumpPoint.setRelatedPlanet(a1);
		//segetia_jump_point.setStandardWormholeToHyperspaceVisual();
		//segetia_jump_point.setCircularOrbit(system.getEntityById("askonia"), 230 - 60, 14350, 860);
		//system.addEntity(segetia_jump_point);


		// makeshift sensor array in counter-orbit to Umbra
		SectorEntityToken askonia_outer_array = system.addCustomEntity(null, "Askonia Fringe Listening Station", "sensor_array_makeshift", Factions.DIKTAT);
		askonia_outer_array.setCircularOrbitPointingDown(star, 280 + 45, 20500, 1400);

		PlanetAPI a1_1 = system.addPlanet("sharib", star, "Sharib", "barren_venuslike", -175, 50, 17350, 860);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 17550, 852f, null, null);
		system.addAsteroidBelt(star, 300, 17550, 270, 800, 500, Terrain.ASTEROID_BELT, null);

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
		//		1, 2, // min/max entities to add
		//		17000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds


		// Umbra - the resistance (or pirates)
		PlanetAPI a4 = system.addPlanet("umbra", star, "Umbra", "rocky_ice", 280, 100, 20500, 1400);
		a4.setCustomDescriptionId("planet_umbra");
		a4.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		a4.getSpec().setGlowColor(new Color(255,255,255,255));
		a4.getSpec().setUseReverseLightForGlow(true);
		a4.applySpecChanges();
		a4.setInteractionImage("illustrations", "pirate_station");

		JumpPointAPI umbra_jump_point = Global.getFactory().createJumpPoint("umbra_jump_point", "Umbra L3 Jump-point");
		//OrbitAPI orbit = Global.getFactory().createCircularOrbit(a1, 0, 4400, 270);
		//jumpPoint.setOrbit(orbit);
		umbra_jump_point.setRelatedPlanet(a4);
		umbra_jump_point.setStandardWormholeToHyperspaceVisual();
		umbra_jump_point.setCircularOrbit(system.getEntityById("askonia"), 280-180, 20500, 1400);
		system.addEntity(umbra_jump_point);
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, false);
	}
	

	
}
