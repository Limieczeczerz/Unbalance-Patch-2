package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

public class AlGebbar {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Al Gebbar");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		//SectorEntityToken eos_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/eos_nebula.png",
		//		0, 0, // center of nebula
		//		system, // location to add to
		//		"terrain", "nebula", // "nebula_blue", // texture to use, uses xxx_map for map
		//		4, 4, StarAge.AVERAGE); // number of cells in texture
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI algebbar_star = system.initStar("algebbar", // unique id for this star 
				StarTypes.BLUE_GIANT, // id in planets.json
				1200f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(210, 230, 255)); // light color in entire system, affects all entities

		//system.setLightColor(new Color(125, 175, 240)); // light color in entire system, affects all entities


		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(800, // terrain effect band width
						2600, // terrain effect middle radius
						algebbar_star, // entity that it's around
						2200f, // visual band start
						3000f, // visual band end
						new Color(0, 0, 0, 0), // base color
						10f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(235, 195, 245, 30),
						new Color(210, 120, 230, 50),
						new Color(130, 50, 150, 90),
						new Color(195, 235, 245, 40),
						new Color(150, 110, 160, 55),
						new Color(225, 245, 195),
						new Color(235, 195, 245)
				));
		field.setCircularOrbit(algebbar_star, 0, 0, 60);

		system.addRingBand(algebbar_star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4000, 200, null, null);
		system.addAsteroidBelt(algebbar_star, 180, 4000, 100, 200, 120, Terrain.ASTEROID_BELT, null);
		
		// Gebbar a
		PlanetAPI gebbar2 = system.addPlanet("gebbar2", algebbar_star, "Kolasis", "lava", 0, 190, 5000, 220);
		gebbar2.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "volturn"));
		gebbar2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		gebbar2.getSpec().setGlowColor(new Color(0, 0, 0, 0));
		gebbar2.getSpec().setPlanetColor(new Color(255,0,10,255));
		gebbar2.applySpecChanges();

		gebbar2.setCustomDescriptionId("planet_kolasis");

		// Al Gebbar Jumppoint
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("algebbar_jump", "Al Gebbar Jump-point");
		jumpPoint2.setCircularOrbit( system.getEntityById("algebbar"), 0 + 60, 5000, 220);
		jumpPoint2.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint2);

		SectorEntityToken field_d1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		field_d1.setCircularOrbit(algebbar_star, 0 + 60, 5000, 220);

		SectorEntityToken field_d2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		field_d2.setCircularOrbit(algebbar_star, 0 - 60, 5000, 220);

		PlanetAPI gebbar3 = system.addPlanet("gebbar3", algebbar_star, "Basanizo", "lava_minor", 40, 115, 10000, 455);
		gebbar3.getSpec().setGlowColor(new Color(235, 195, 245, 255));
		gebbar3.getSpec().setPlanetColor(new Color(105,60,115,255));
		//gebbar3.getSpec().setAtmosphereColor(new Color(255,255,255,155));
		gebbar3.applySpecChanges();
		gebbar3.applySpecChanges();

		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 6000, 350, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 6600, 350, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 6800, 420, Terrain.RING, null);

		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7400, 440, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7550, 520, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 7800, 460, Terrain.RING, null);

		//system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 8500, 310f, null, null);

		PlanetAPI gebbar4 = system.addPlanet("epiphany", algebbar_star, "Epiphany", "barren-bombarded", 270, 40, 12000, 645);
			gebbar4.setCustomDescriptionId("planet_epiphany");	
			gebbar4.getSpec().setPlanetColor(new Color(255,240,225,255));
			gebbar4.applySpecChanges();
			system.addRingBand(gebbar4, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 400, 40f);
			system.addAsteroidBelt(gebbar4, 20, 400, 40, 30, 50, Terrain.ASTEROID_BELT, "Custodes");
			
			// btw, jump-point is related to this one.
			jumpPoint2.setRelatedPlanet(gebbar3);

		PlanetAPI gebbar4a = system.addPlanet("ankhothi", algebbar_star, "Ankhothi", "ice_giant", 270 - 30, 290, 12000, 645);
		gebbar4a.getSpec().setPlanetColor(new Color(210,115,245,255));
		gebbar4a.getSpec().setCloudColor(new Color(0,0,0,255));
		gebbar4a.applySpecChanges();

		SectorEntityToken al_gebbar_loc1 = system.addCustomEntity(null,null, "nav_buoy_makeshift",Factions.LUDDIC_PATH);
		al_gebbar_loc1.setCircularOrbitPointingDown( algebbar_star, 270 - 60, 12000, 645);

		PlanetAPI gebbar5 = system.addPlanet("gebbar5", algebbar_star, "Loutron", "cryovolcanic", 90, 120, 14800, 845);
		gebbar5.getSpec().setPlanetColor(new Color(235,255,245,255));
		//gebbar5.getSpec().setPlanetColor(new Color(150,110,160,255));
		//gebbar5.getSpec().setCloudColor(new Color(255,255,255,255));
		gebbar5.applySpecChanges();

		SectorEntityToken abandoned_station = system.addCustomEntity("abandoned_station", "Abandoned Skyhook Anchor", "station_mining00", "neutral");
		abandoned_station.setCircularOrbitPointingDown(system.getEntityById("gebbar5"), 90, 220, 25);
		abandoned_station.setCustomDescriptionId("station_abandoned_mining");
		abandoned_station.setInteractionImage("illustrations", "orbital_construction");
		abandoned_station.addTag("abandoned");
		abandoned_station.addTag("volatiles_extraction_platform");

		SectorEntityToken al_gebbar_loc2 = system.addCustomEntity(null,null, "stable_location",Factions.NEUTRAL);
		al_gebbar_loc2.setCircularOrbitPointingDown( algebbar_star, 90 + 60, 14800, 845);

		SectorEntityToken nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
						"xx  x " +
						" xxx x" +
						" xxxx " +
						" xx xx" +
						"   x  ",
				6, 5, // size of the nebula grid, should match above string
				"terrain", "nebula_amber", 4, 4, null));
		nebula.setCircularOrbit(algebbar_star, 90 - 60, 14800, 845);

		system.addRingBand(algebbar_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 13900, 740, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14000, 820, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14200, 660, Terrain.RING, null);
		system.addRingBand(algebbar_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 14200, 660, Terrain.RING, null);
		//system.addRingBand(algebbar_star, "misc", "rings_ice0", 512f, 2, Color.white, 256f, 14400, 660, Terrain.RING, null);
		//system.addRingBand(algebbar_star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 14500, 660, Terrain.RING, null);
			
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
