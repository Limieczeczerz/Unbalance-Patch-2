package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.ids.Entities;

public class Naraka {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Naraka");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI naraka_star = system.initStar("naraka", // unique id for this star 
											    "star_orange",  // id in planets.json
											    650f, 		  // radius (in pixels at default zoom)
											    400, // corona
											    5f, // solar wind burn level
												0.65f, // flare probability
												2.2f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(255, 220, 200)); // light color in entire system, affects all entities

		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(200f, // terrain effect band width
						1740, // terrain effect middle radius
						naraka_star, // entity that it's around
						1640f, // visual band start
						1840f, // visual band end
						new Color(155, 255, 255, 10), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(156, 255, 221, 30),
						new Color(156, 224, 255, 50),
						new Color(156, 255, 187, 90),
						new Color(255, 192, 156, 50),
						new Color(164, 191, 191, 55),
						new Color(156, 255, 255),
						new Color(170, 155, 146)
				));
		field.setCircularOrbit(naraka_star, 0, 0, 55);
		
		SectorEntityToken naraka_stable1 = system.addCustomEntity(null, null, "stable_location", "neutral");
		naraka_stable1.setCircularOrbitPointingDown(naraka_star, 0, 2250, 160);
		
		system.addRingBand(naraka_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 2800, 220f, Terrain.RING, "The Yamuna");
		
		PlanetAPI naraka_b = system.addPlanet("yama", naraka_star, "Yama", "arid", 60, 165, 4100, 140);
		naraka_b.setCustomDescriptionId("planet_yama");
			PlanetAPI naraka_b1 = system.addPlanet("yami", naraka_b, "Yami", "barren-bombarded", 0, 60, 450, 40);
		
		// Yamidutas : asteroids
		system.addAsteroidBelt(naraka_b, 60, 900, 170, 200, 250, Terrain.ASTEROID_BELT, "The Servants");
		system.addRingBand(naraka_b, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 900, 220f);
		
		PlanetAPI naraka_b2 = system.addPlanet("nachiketa", naraka_star, "Nachiketa", "barren", 60 - 60, 65, 4100, 140);
		naraka_b2.setCustomDescriptionId("planet_nachiketa");
		naraka_b2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		naraka_b2.getSpec().setGlowColor(new Color(255,60,240,200));
		naraka_b2.getSpec().setUseReverseLightForGlow(true);
		naraka_b2.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "barren02"));
		naraka_b2.applySpecChanges();

		// Naraka Relay
		SectorEntityToken relay = system.addCustomEntity("naraka_relay", "Naraka Relay", "comm_relay", "hegemony");
		relay.setCircularOrbitPointingDown(system.getEntityById("naraka"), 60 + 180, 4100, 140);
		
		// naraka jump-point

		system.addRingBand(naraka_star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 5600, 440f, Terrain.RING, null);
		
		PlanetAPI naraka_c = system.addPlanet("chitagupta", naraka_star, "Chitagupta", "barren", 90, 100, 6750, 380);

		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("naraka_jump", "Naraka Jump-point");
		jumpPoint1.setCircularOrbit( system.getEntityById("naraka"), 60 + 60, 6750, 380);
		jumpPoint1.setRelatedPlanet(naraka_c);
		system.addEntity(jumpPoint1);

		PlanetAPI malaya = system.addPlanet("balar", naraka_star, "Malaya", "ice_giant", 60, 340, 9500, 410);
		malaya.getSpec().setPlanetColor(new Color(255,215,245,255));
		malaya.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		malaya.getSpec().setGlowColor(new Color(255,0,205,64));
		malaya.getSpec().setUseReverseLightForGlow(true);
		malaya.getSpec().setTilt(30);
		malaya.applySpecChanges();

		SectorEntityToken malayaL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						1000f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		SectorEntityToken malayaL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						1000f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		malayaL4.setCircularOrbit(naraka_star, 60 + 60, 9500, 410);
		malayaL5.setCircularOrbit(naraka_star, 60 - 60, 9500, 410);
		
		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, naraka_star, StarAge.AVERAGE,
				6, 7, // min/max entities to add
				11500, // radius to start adding at
				3, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds
		
		//StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}